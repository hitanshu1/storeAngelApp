class LatLongFromAddress{

  double lat;
  double long;

  LatLongFromAddress({this.lat,this.long});
}