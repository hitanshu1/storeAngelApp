
import 'package:storeangelApp/core/models/user.dart';

class PackageModel{
  UserModel clientDetails;
  int totalItems;
  PackageModel({this.clientDetails,this.totalItems});
}