class ResponseModel{
  int status;
  String message;
  ResponseModel({this.message,this.status});
}