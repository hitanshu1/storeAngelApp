

class AppInitialValue {
  bool darkMode;
  bool isAlready;
  bool isBackgroundImageActive;
  String backGroundImagePath;
  double opacity;

  AppInitialValue(
      {this.isAlready: true, this.darkMode: false, this.isBackgroundImageActive: false, this.backGroundImagePath,this.opacity});
}