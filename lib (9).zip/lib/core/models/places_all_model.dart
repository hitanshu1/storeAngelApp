
class Place{
  String name;
  double lat;
  double long;
  String street;
  String city;
  String zipCode;
  String country;
  String address;


  Place({this.name,this.lat,this.address, this.long,this.street,this.city,this.country,this.zipCode});
}
