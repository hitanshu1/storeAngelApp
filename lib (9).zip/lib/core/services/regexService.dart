class RegexService {

  static final doubleRegexWithCommaOrDotAndTwoDigit = RegExp(r'(^[0-9]+,|.?[0-9]{0,2})');
}