class ImageService{

  static void getAndSaveImage(){

  }
}