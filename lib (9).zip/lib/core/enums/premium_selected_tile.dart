

enum PremiumSelectedTile {left, middle, right}