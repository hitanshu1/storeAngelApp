enum OrderPurchaseStatus {
  PlaceAOrder,
  InOrder,
  OrderPlaced,
  Purchasing,
  OrderRunning,
  MoneyTransfer,
  OrderDelivered,
  Rejected
}
