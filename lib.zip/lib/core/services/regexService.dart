class RegexService {

  static final doubleRegexWithCommaAndTwoDigit = RegExp(r'(^[0-9]+,?[0-9]{0,2})');
}