import 'package:storeangelApp/core/models/rating_model.dart';

class NumberService{

  static String addAfterCommaTwoZeros(String num){
    String newNum;

    if(num.contains(RegExp(r'(^[0-9]+,?[0-9]{0,2})'))){
      final List<String> stringList = num.split(RegExp(r'[,]'));
      final String afterCommaString = stringList.length==2?stringList.last:'';
      newNum = stringList.first;

      switch(afterCommaString.length){
        case 0:
          return newNum +=',00';
        case 1:
          return newNum+=','+stringList.last[0]+'0';
        case 2:
          return num;
        default:
          return '';
      }
    }
    return '';
  }

  static double averageRating(List<RatingModel>ratings){
    if(ratings!=null){
      return ratings.map((m) => m.rating).reduce((a, b) => a + b) / ratings.length;
    }else{
      return 0;
    }
  }
}