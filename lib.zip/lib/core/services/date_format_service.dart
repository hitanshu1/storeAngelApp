
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class DateFormatService{
  static String getDateFormat(String dateString,BuildContext context){
    var dateTime = DateTime.parse(dateString);
    String languageCode = Localizations.localeOf(context).languageCode;
//    String date='${DateFormat('dd. MMM. yyyy',languageCode).format(dateTime)}';
    String date='${DateFormat('yyyy-MM-dd',languageCode).format(dateTime)}';

    return date;
  }
  static String getDateFormatDDMMM(String dateString,BuildContext context){
    var dateTime = DateTime.parse(dateString);
    String languageCode = Localizations.localeOf(context).languageCode;
//    String date='${DateFormat('dd MMM',languageCode).format(dateTime)}';
    String date='${DateFormat('yyyy-MM-dd',languageCode).format(dateTime)}';
    return date;
  }
}