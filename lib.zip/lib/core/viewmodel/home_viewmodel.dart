import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:location/location.dart';
import 'package:storeangelApp/core/consts/appConstants.dart';
import 'package:storeangelApp/core/models/order.dart';
import 'package:storeangelApp/core/models/places_all_model.dart';
import 'package:storeangelApp/core/models/purchase_deatails.dart';
import 'package:storeangelApp/core/services/firebase_abstraction.dart';
import 'package:storeangelApp/core/services/statusbar_service.dart';
import 'package:storeangelApp/getIt.dart';
import 'package:storeangelApp/ui/shared/base_model.dart';

class HomeViewModel extends BaseModel {
  List<Place> places = <Place>[];
  List<PurchaseDetails>watchlist=[];
  List<PurchaseDetails>notificationList=[];

  var location = new Location();
  FirebaseAbstraction _myFirebaseServices = getIt<FirebaseAbstraction>();
  bool running=true;
  double _latitude;
  double _longitude;
  List<OrderOrPurchases>orderList=[];

  int selectedIndex = 0;

  void setSelectedIndex(int index){
    selectedIndex = index;
    setState(ViewState.Idle);
  }

  void navigatorPop() {
    navigationService.pop();
  }
  void navigateToScreen(String routeName,BuildContext context,{Object arguments}) {
    navigationService.navigateTo(routeName, arguments: arguments).then((value){
      StatusBarService.changeStatusBarColor(StatusBarType.Gray, context);
    });
  }

  void initialize(){
    getUserNotificationList();
    getOrderList(running);
  }

  Future<List<Place>> getAllPlaces(String placename) async {
    setState(ViewState.Busy);
    try {
      LocationData currentLocation = await location.getLocation();

      _latitude = currentLocation.latitude;

      _longitude = currentLocation.longitude;

    } catch (e) {
      print(e);
    }

    var uri = Uri.parse(
        AppConstants.googleQueryLink +
            placename +
            "&location=" +
            _latitude.toString() +
            "," +
            _longitude.toString() +
            "&radius=4000");

    final response = await http.get(uri, headers: {"Accept": "application/json"});

    List data = json.decode(response.body)["predictions"];

    places.clear();
//    data.forEach((f) => places.add(new Place(
//          f["structured_formatting"]["main_text"],
//          f["description"]
//        )));
    data.forEach((f) => places.add(new Place(
      name: f["structured_formatting"]["main_text"]
    )));

    setState(ViewState.Idle);

    return places;
  }
  void changeView(bool value){
    setState(ViewState.Busy);
    running=value;
    setState(ViewState.Idle);
  }

  Future getOrderList(bool value)async{
    setState(ViewState.Busy);
    orderList =await _myFirebaseServices.getOrderList();
    setState(ViewState.Idle);


  }

  Future getUserWatchlist()async{
    setState(ViewState.Busy);
    watchlist=await _myFirebaseServices.getUserWishList('useId');
    setState(ViewState.Idle);

  }

  Future getUserNotificationList()async{
    setState(ViewState.Busy);

    //List is not supposed to be longer than 10 items
    List<PurchaseDetails> list =(await _myFirebaseServices.getUserNotificationList('useId'));
    notificationList = list.take(10).toList();
    setState(ViewState.Idle);
  }

}
