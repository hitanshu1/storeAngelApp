import 'package:storeangelApp/core/models/order.dart';
import 'package:storeangelApp/core/services/firebase_abstraction.dart';
import 'package:storeangelApp/ui/screens/courier/order_information_screen.dart';
import 'package:storeangelApp/ui/shared/base_model.dart';
import '../../getIt.dart';

class HomeFirstUseViewModel extends BaseModel{

  FirebaseAbstraction database=getIt<FirebaseAbstraction>();
  List<OrderOrPurchases>assignOrders=[];

  Future getAssignOrderList(String courierId)async{
    setState(ViewState.Busy);
    assignOrders=await database.getAssignOrderForCourier(courierId);

    setState(ViewState.Idle);
  }

  Future<void> navigatetoOrderInformationScreen(int index)async{
    await navigationService.navigateTo(OrderInformationScreen.routeName, arguments: assignOrders[index]);
  }
}