
class DatabaseUrls{
  static final colUsers='col_Users';
  static final colProducts='col_Products';
  static final colOrders='col_Orders';
  static final colShopList='col_Shop_List';
  static final colStores='col_Stores';
  static final colPayments='col_Payments';
  static final colNotifications='col_Notifications';
}