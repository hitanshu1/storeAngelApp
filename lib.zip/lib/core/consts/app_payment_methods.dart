class AppPaymentMethods{
  static String payPal='PayPal';
  static String applePay='Apple Pay';
  static String googlePay='Google Pay';
  static String sofortPay='Sofort Uberweisung';
  static String amazonPay='Amazon Pay';
  static String cardPay='Credit/Debit Card';
}