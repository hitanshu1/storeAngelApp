
import 'package:flutter/material.dart';


class AppColors{

  static const Color primaryColor = Color(0xFF27BB8B);
  static const Color backgroundColor = Color(0xFFF0EBE6);
  static const Color backgroundDarkColor = Color(0xFF19191E);
  static const Color facebookButtonColor = Color(0xFF3b5998);
  static const Color whiteColor = Color(0xFFFFFFFF);
  static const Color blackFontColor = Color(0xFF333333);
  static const Color black = Color(0xFF000000);
  static final Color lightGreyColor = Colors.grey[400];
  static const Color lightGrayDotColor = Color(0xFFD8D8D8);
  static const Color darkCardColor = Color(0xFF313237);
  static const Color secondDarkCardColor = Color(0xFF46474e);
  static const Color thirdDarkColor = Color(0xFF575861);
  static const Color darkGrayColor = Color(0xFF777777);
  static const Color grayFont=Color(0xFF878787);
  static const Color grayDarkThemeFont=Color(0xFFd9d9d9);
  static const Color darkGrayLittleColor = Color(0xFF9B9B9B);
  static const Color lightGrayLittleColor = Color(0xFFDDDDDD);
  static const Color grayBackgroundColor=Color(0xFFF7F7F7);
  static final Color amber=Color( 0xFFFcd303);
  static final Color red=Color(0xFFF81B08).withOpacity(1);
  static final Color veryLightGrayColor=Color(0xFFF6F6F6).withOpacity(1);
  static final Color activeColor=Color(0xFF28BE8C).withOpacity(1);
  static final Color bottomNavigationBarDarkColor = Color(0xFF23232a);
  static final Color bottomNavigationBarLightColor = backgroundColor;
  static const Color ownTextMessageColor = Color(0xFF9BEBD1);
  static final Color otherTextMessageColor = Colors.grey[300];
  static final Color blueVerifyColor = Color(0xFF1787E0);


  static const Color greenLigthColorMarkerCircle1=Color.fromRGBO(39, 187, 139, 0.09);
  static const Color greenLigthColorMarkerCircle2= Color.fromRGBO(39, 187, 139, 0.06);
  static const Color greenLigthColorMarkerCircle3= Color.fromRGBO(39, 187, 139, 0.04);

  static const Color green=Color.fromRGBO(39, 187, 139, 1);

}




