
import 'dart:io';
import 'dart:typed_data';

class AppImage{
  File fileImage;
  Uint8List uinT8List;
  AppImage({this.uinT8List,this.fileImage});

}