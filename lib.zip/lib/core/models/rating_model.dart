
import 'package:storeangelApp/core/models/user.dart';

class RatingModel{
  int rating;
  UserModel rateBy;
  RatingModel({this.rateBy,this.rating});
}