class AddressModel {
  String state;
  String street;
  String city;
  String zipCode;
  String country;
  String apartment;
  String entrance;
  String name;
  bool isSelected;
  String floor;

  AddressModel({
    this.state,

    this.country,
    this.apartment,
    this.entrance,
    this.floor,
    this.name,
    this.isSelected: false,
    this.street: '',
    this.city:'',
    this.zipCode: '',
  });

  String get address =>street+', '+zipCode+' '+city;
}
