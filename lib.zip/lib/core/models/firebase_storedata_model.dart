
import 'package:storeangelApp/core/models/rating_model.dart';

enum PaymentType{Prepaid,PayOnDelivery,Both}

class StoreDataModel {
  String id;
  String name;
  String street;
  String city;
  String txtZip;
  String country;
  String openingTime;
  String closingTime;
  String image;
  String documentId;
  String landMark;
  bool isChecked;
  String webSitUrl;
  int likes;
  List<RatingModel>ratings;
  PaymentType paymentType;
  // String created;

  StoreDataModel(
      {this.id,
      this.isChecked: false,
      this.webSitUrl: '',
      this.name: '',
      this.city: '',
      this.street: '',
      this.landMark,
      this.txtZip: '',
      this.country: 'Germany',
      this.image,
      this.documentId,
      this.openingTime,
      this.likes,
      this.closingTime,this.ratings,this.paymentType:PaymentType.Prepaid});

  String get fullAddress=>name+', '+city+', '+street+', '+txtZip;

  String get addressLine => city + ', ' + street;

  String get zipCity => txtZip + ' ' + city;

  String get address => street + ', ' + txtZip + ' ' + city;
}
