
class BudgetNameModel {
  String name;
  String description;
  BudgetNameModel({this.name,this.description});
}