import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:storeangelApp/core/consts/appColors.dart';
import 'package:storeangelApp/core/consts/appString.dart';
import 'package:storeangelApp/core/consts/sizeConfig.dart';
import 'package:storeangelApp/core/consts/storeangel_icons_icons.dart';
import 'package:storeangelApp/core/viewmodel/mainApp_viewmodel.dart';
import 'package:storeangelApp/core/viewmodel/viewmodel_profile.dart';

class AppBottomNavigationBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      type: BottomNavigationBarType.fixed,
      elevation: 20,
      currentIndex: Provider.of<MainAppViewModel>(context, listen: true).bottomNavigationIndex,
      onTap: (val) {
        Provider.of<MainAppViewModel>(context, listen: false).setBottomNavigationIndex(val);
        Provider.of<ProfileViewModel>(context, listen: false).changeView(ProfilePageView.home);
      },
      selectedItemColor: AppColors.primaryColor,
      unselectedItemColor: Theme.of(context).textTheme.headline5.color,
      selectedFontSize: SizeConfig.fontSizeSmall,
      unselectedFontSize: SizeConfig.fontSizeSmall,
      items: <BottomNavigationBarItem>[
        BottomNavigationBarItem(
            icon: _customIcon(StoreangelIcons.home_tab),
            activeIcon: _customIcon(StoreangelIcons.home_tab_full),
            label: AppStrings.HOME.tr()),
        BottomNavigationBarItem(
          icon: _customIcon(StoreangelIcons.watchlist_tab),
          activeIcon: _customIcon(StoreangelIcons.watchlist_tab_full),
          label: AppStrings.TAB_LABLE_LISTS.tr(),
        ),
        BottomNavigationBarItem(
          icon: _customIcon(StoreangelIcons.stores_tab),
          activeIcon: _customIcon(StoreangelIcons.stores_tab_full),
          label: AppStrings.STORE.tr(),
        ),
        BottomNavigationBarItem(
          icon: _customIcon(StoreangelIcons.profile_courier_tab),
          activeIcon: _customIcon(StoreangelIcons.profile_courier_tab),
          label: AppStrings.TAB_LABLE_PROFILE.tr(),
        ),
      ],
    );
  }

  Widget _customIcon(IconData icon) {
    return Padding(
        padding: EdgeInsets.only(top: SizeConfig.screenHeight * .008, bottom: SizeConfig.screenHeight * .003),
        child: Icon(
          icon,
          size: 24,
        ));
  }
}
