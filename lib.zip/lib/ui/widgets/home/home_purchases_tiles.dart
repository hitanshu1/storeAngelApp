import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:storeangelApp/core/consts/appColors.dart';
import 'package:storeangelApp/core/consts/appConstants.dart';
import 'package:storeangelApp/core/consts/appString.dart';
import 'package:storeangelApp/core/consts/sizeConfig.dart';
import 'package:storeangelApp/core/consts/text_styles.dart';
import 'package:storeangelApp/core/viewmodel/home_viewmodel.dart';
import 'package:storeangelApp/ui/shared/base_model.dart';
import 'package:storeangelApp/ui/shared/buttonWithIcon.dart';
import 'package:storeangelApp/ui/shared/premium_card.dart';

import 'order_list_item_widget.dart';

class HomePurchasesTiles extends StatelessWidget {
  final EdgeInsets sidePadding;

  const HomePurchasesTiles({Key key,@required this.sidePadding}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<HomeViewModel>(
      builder: (context, homeViewModel, child) {
        if (homeViewModel.state == ViewState.Busy) {
          return SliverToBoxAdapter(
            child: AppConstants.circulerProgressIndicator(),
          );
        } else {
          if (homeViewModel.orderList.length > 0) {
            return SliverList(
                delegate: SliverChildBuilderDelegate(
                      (context, int index) {
                    if (homeViewModel.orderList.length == index)
                      return Padding(
                        padding: SizeConfig.padding.copyWith(top: SizeConfig.bottomPadding.bottom*.5),
                        child: Column(
                          children: [
                            PremiumCard(
                              title: AppStrings.GET_PREMIUM_NOW.tr(),
                              subtitle: AppStrings.GET_PREMIUM_POTENTIAL.tr(),
                            ),
                            SizeConfig.CVerticalSpaceSmallMedium()
                          ],
                        ),
                      );
                    return Padding(
                      padding: sidePadding.copyWith(bottom: SizeConfig.bottomPadding.bottom*.5),
                      child: OrderItemListWidget(
                        model: homeViewModel,
                        order: homeViewModel.orderList[index],
                        running: homeViewModel.running,
                      ),
                    );
                  },
                  childCount: homeViewModel.orderList.length + 1,
                ));
          } else {
            return SliverToBoxAdapter(
              child: Padding(
                padding: sidePadding.copyWith(
                    bottom: SizeConfig.screenHeight * .02
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      AppStrings.NO_RUNNING_ORDER_YET.tr(),
                      style: AppStyles.BlackStyleFont_20(context),
                    ),
                    SizeConfig.verticalSpaceMedium(),
                    Center(
                      child: ButtonWithIcon(
                          height: 50,
                          weight: SizeConfig.screenWidth * .5,
                          buttonColor: AppColors.green,
                          radius: AppConstants.button_Radius,
                          icon: Icons.add_circle,
                          iconSize: SizeConfig.iconSize * 1.2,
                          fontSize: SizeConfig.fontSizeMedium,
                          buttonText: AppStrings.CREATE_A_LIST.tr(),
                          onPressed: () {}),
                    ),
                  ],
                ),
              ),
            );
          }
        }
      },
    );
  }
}
