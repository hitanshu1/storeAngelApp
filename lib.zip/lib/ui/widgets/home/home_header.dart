import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:storeangelApp/core/consts/appString.dart';
import 'package:storeangelApp/core/consts/sizeConfig.dart';
import 'package:storeangelApp/core/consts/text_styles.dart';

class HomeHeader extends StatelessWidget {
  final EdgeInsets sidePadding;

  const HomeHeader({Key key,@required this.sidePadding}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SliverToBoxAdapter(
      child: Container(
        padding: SizeConfig.smalltopPadding,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizeConfig.CVerticalSpace60(),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                SizedBox(
                  width:SizeConfig.screenWidth*.9,
                  child: Text(
                    "Hi Jessica!",
                    style: AppStyles.GreenStyleWithBoldFont_24(context),
                    textAlign: TextAlign.start,
                  ),
                ),
                SizedBox(
                  height: 4,
                ),
                Text(
                  AppStrings.GET_SOME_SHOPPING.tr(),
                  style: AppStyles.BlackStyleFontw300_20(context),
                  textAlign: TextAlign.start,
                ),
                SizedBox(
                  height: 6,
                ),

              ],
            ),
          ],
        ),
      ),
    );
  }
}
