import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:storeangelApp/core/consts/appColors.dart';
import 'package:storeangelApp/core/consts/appConstants.dart';
import 'package:storeangelApp/core/consts/appString.dart';
import 'package:storeangelApp/core/consts/apptheme.dart';
import 'package:storeangelApp/core/consts/sizeConfig.dart';
import 'package:storeangelApp/core/consts/storeangel_icons_icons.dart';
import 'package:storeangelApp/core/consts/text_styles.dart';
import 'package:storeangelApp/core/services/sharedPreference.dart';
import 'package:storeangelApp/core/viewmodel/apptheme_viewmodel.dart';
import 'package:storeangelApp/core/viewmodel/viewmodel_profile.dart';
import 'package:storeangelApp/ui/screens/consumer/landing_Screen.dart';
import 'package:storeangelApp/ui/screens/courier/courier_signup_screen.dart';
import 'package:storeangelApp/ui/screens/courier/payment_method_screen.dart';
import 'package:storeangelApp/ui/screens/premiumScreen.dart';
import 'package:storeangelApp/ui/shared/base_model.dart';
import 'package:storeangelApp/ui/shared/circleIcon.dart';
import 'package:storeangelApp/ui/shared/customCard.dart';
import 'package:storeangelApp/ui/shared/customScaffold.dart';
import 'package:storeangelApp/ui/shared/platform_alert_dialog.dart';
import 'package:storeangelApp/ui/shared/premium_card.dart';
import 'package:storeangelApp/ui/shared/profile_option_widget.dart';
import 'package:storeangelApp/ui/shared/showbottomSheet.dart';
import 'package:storeangelApp/ui/shared/view_app_Image.dart';
import 'package:storeangelApp/ui/widgets/home/myaddress_view.dart';

import '../../../getIt.dart';

class ProfileView extends StatefulWidget {
  final bool agentView;

  ProfileView({this.agentView: false});

  @override
  _ProfileViewState createState() => _ProfileViewState();
}

class _ProfileViewState extends State<ProfileView> {
  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      body: Consumer<ProfileViewModel>(
        builder: (context, profileViewModel, child) {
          if (profileViewModel.state == ViewState.Busy) {
            return AppConstants.circulerProgressIndicator();
          } else {
            return SingleChildScrollView(
              child: _getWidget(false, profileViewModel),
            );
          }
        },
      ),
    );
  }

  Widget _getWidget(bool hasSpacer, ProfileViewModel profileViewModel) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.only(
              left: SizeConfig.smalltpadding.left,
              right: SizeConfig.smalltpadding.right,
              top: SizeConfig.screenHeight * .07,
              bottom: SizeConfig.screenHeight * .01),
          color: Theme.of(context).backgroundColor,
          child: Row(
            children: [
              ViewAppImage(
                height: SizeConfig.smallerImageHeight,
                width: SizeConfig.smallerImageHeight,
                imageUrl: profileViewModel.user.imageUrl != null && profileViewModel.user.imageUrl.isNotEmpty
                    ? profileViewModel.user.imageUrl
                    : 'https://firebasestorage.googleapis.com/v0/b/gpat-test.appspot.com/o/sample_profile.png?alt=media&token=5bbcd983-45aa-4c98-8487-1b8a79650ac7',
                radius: SizeConfig.smallerImageHeight,
                boxFit: BoxFit.none,
              ),
              SizeConfig.horizontalSpaceSmall(),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${(profileViewModel.user?.name?.isNotEmpty ?? false) && profileViewModel.user?.name != null ? profileViewModel.user.name : 'Lina Flores'}',
                      style: AppStyles.BlackStyleWithBold800Font_20(context),
                    ),
                    Text(
                      '${widget.agentView ? AppStrings.COURIER.tr() : AppStrings.CUSTOMER.tr()}',
                      style: AppStyles.BlackStyleFont_16(context),
                    )
                  ],
                ),
              ),
              TextButton(
                  onPressed: () {
                    profileViewModel.signOut();
                  },
                  child: Text(
                    AppStrings.SIGN_OUT.tr(),
                    style: AppStyles.GreenStyleWithBold600_Font16(context),
                  )),
            ],
          ),
        ),
        Padding(
          padding: SizeConfig.padding.copyWith(
              top: !widget.agentView ? SizeConfig.verticalMediumPadding.top : SizeConfig.verticalC13Padding.top, bottom: 0),
          child: CustomCard(
            child: widget.agentView
                ? Column(
                    children: [
                      SizeConfig.CVerticalSpaceVarySmall(),
                      ProfileOptionWidget(
                        icon: StoreangelIcons.profile_courier_tab,
                        title: AppStrings.PERSONAL_INFORMATION.tr(),
                        onTap: () {
                          profileViewModel.changeView(ProfilePageView.personalInfo);
                        },
                      ),


                      ProfileOptionWidget(
                        icon: Icons.payment,
                        title: AppStrings.PAYMENT_OPTIONS.tr(),
                        onTap: () {
                          profileViewModel.changeView(ProfilePageView.paymentOptions);
                        },
                      ),
                      ProfileOptionWidget(
                        icon: StoreangelIcons.diamond_full,
                        title: AppStrings.PREMIUM_UPGRADE.tr(),
                        onTap: () async {
                          profileViewModel.changeView(ProfilePageView.premium);
                          await profileViewModel.navigateToScreen(PremiumScreen.routeName);
                          profileViewModel.changeView(ProfilePageView.home);
                        },
                      ),
                      ProfileOptionWidget(
                        icon: Icons.settings,
                        title: AppStrings.SETTINGS.tr(),
                        onTap: () {
                          profileViewModel.changeView(ProfilePageView.setting);
                        },
                      ),
                      ProfileOptionWidget(
                        icon: StoreangelIcons.notifications_icon,
                        title: AppStrings.NOTIFICATIONS.tr(),
                        onTap: () {
                          profileViewModel.changeView(ProfilePageView.notifications);
                        },
                      ),
                      ProfileOptionWidget(
                        icon: Icons.feedback,
                        title: AppStrings.CONTACT_AND_HELP.tr(),
                        onTap: () {
                          profileViewModel.changeView(ProfilePageView.feedback);
                        },
                      ),
                      ProfileOptionWidget(
                        borderColor: widget.agentView,
                        icon: StoreangelIcons.password_icon,
                        title: AppStrings.PRIVACY.tr(),
                        onTap: () {
                          profileViewModel.changeView(ProfilePageView.privacy);
                        },
                      ),
                      ProfileOptionWidget(
                        borderColor: false,
                        icon: StoreangelIcons.insurance_icon,
                        title: AppStrings.INSURANCE.tr(),
                        onTap: () {
                          profileViewModel.changeView(ProfilePageView.insurance);
                        },
                      ),
                      SizeConfig.CVerticalSpaceVarySmall(),
                    ],
                  )
                : Column(
                    children: [
                      SizeConfig.CVerticalSpaceVarySmall(),
                      ProfileOptionWidget(
                        icon: StoreangelIcons.profile_consumer_tab,
                        title: AppStrings.PERSONAL_INFORMATION.tr(),
                        onTap: () {
                          profileViewModel.changeView(ProfilePageView.personalInfo);
                        },
                      ),
                      ProfileOptionWidget(
                        icon: Icons.location_on,
                        title: AppStrings.DELIVERY_ADDRESSES.tr(),
                        onTap: () {
                          profileViewModel.changeView(ProfilePageView.myAddress);
                        },
                      ),
                      ProfileOptionWidget(
                        icon: Icons.settings,
                        title: AppStrings.SETTINGS.tr(),
                        onTap: () {
                          profileViewModel.changeView(ProfilePageView.setting);
                        },
                      ),
                      ProfileOptionWidget(
                        icon: StoreangelIcons.diamond_full,
                        title: AppStrings.PREMIUM_UPGRADE.tr(),
                        onTap: () async {
                          profileViewModel.changeView(ProfilePageView.premium);
                          await profileViewModel.navigateToScreen(PremiumScreen.routeName);
                          profileViewModel.changeView(ProfilePageView.home);
                        },
                      ),
                      ProfileOptionWidget(
                        icon: Icons.feedback,
                        title: AppStrings.CONTACT_AND_HELP.tr(),
                        onTap: () {
                          profileViewModel.changeView(ProfilePageView.feedback);
                        },
                      ),
                      ProfileOptionWidget(
                        icon: StoreangelIcons.notifications_icon,
                        title: AppStrings.NOTIFICATIONS.tr(),
                        onTap: () {
                          profileViewModel.changeView(ProfilePageView.notifications);
                        },
                      ),
                      ProfileOptionWidget(
                        borderColor: widget.agentView,
                        icon: StoreangelIcons.password_icon,
                        title: AppStrings.PRIVACY.tr(),
                        onTap: () {
                          profileViewModel.changeView(ProfilePageView.privacy);
                        },
                      ),
                      SizeConfig.CVerticalSpaceVarySmall(),
                    ],
                  ),
          ),
        ),
        _changeToOtherUserType(profileViewModel),
        Padding(
            padding: SizeConfig.padding.copyWith(top: 0),
            child: PremiumCard(
              title: AppStrings.GET_PREMIUM_NOW.tr(),
              subtitle: AppStrings.GET_PREMIUM_POTENTIAL.tr(),
            )),
        SizeConfig.CVerticalSpaceSmallMedium()
      ],
    );
  }

  Widget _changeToOtherUserType(ProfileViewModel profileViewModel) {
    return Padding(
      padding: SizeConfig.padding.copyWith(top: SizeConfig.bottomPadding.bottom, bottom: SizeConfig.bottomPadding.bottom),
      child: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).primaryColor,
          borderRadius: BorderRadius.circular(AppConstants.ContainerRoundCorner_Radius),
        ),
        height: SizeConfig.adaptiveHeight(SizeConfig.screenHeight * .125),
        child: Padding(
          padding: SizeConfig.verticalMediumPadding,
          child: InkWell(
            onTap: () => onTapChangeUser(context, profileViewModel),
            child: Row(
              children: [
                SizeConfig.horizontalSpaceSmall(),
                CircleIcon(
                  icon: widget.agentView
                      ? StoreangelIcons.profile_consumer_tab
                      : StoreangelIcons.profile_courier_tab,
                  iconColor: Theme.of(context).primaryColor,
                  backgroundColor: Provider.of<AppThemeViewModel>(context).themeData == AppTheme.dark
                      ? AppColors.darkCardColor
                      : AppColors.whiteColor,
                  iconSize: SizeConfig.screenHeight * .055,
                  size: Size(SizeConfig.screenHeight * .08, SizeConfig.screenHeight * .08),
                ),
                SizeConfig.horizontalSpaceSmall(),
                Expanded(
                    child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      widget.agentView ? AppStrings.SWITCH_TO_CUSTOMER.tr() : AppStrings.WORK_AS_A_COURIER.tr(),
                      style: AppStyles.BlackStyleWithBold800Font_20(context).copyWith(color: AppColors.whiteColor),
                    ),
                    SizedBox(
                      height: 4,
                    ),
                    Text(
                      widget.agentView
                          ? AppStrings.SWITCH_TO_CUSTOMER_DESCRIPTION.tr()
                          : AppStrings.SWITCH_TO_COURIER_TEXT.tr(),
                      style: AppStyles.BlackStyleFont_16(context).copyWith(color: AppColors.whiteColor),
                    ),
                  ],
                )),
                SizeConfig.horizontalSpaceSmall(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<bool> _showDialog(String text, String content) {
    return PlatformAlertDialog(
      title: text,
      content: content,
      defaultActionText: AppStrings.YES.tr(),
      defaultActionText2: AppStrings.NO.tr(),
      defaultFunction2: () {
        Navigator.of(context, rootNavigator: true).pop(false);
      },
    ).show(context);
  }

  void onTapChangeUser(BuildContext context, ProfileViewModel profileViewModel) async {
    if (widget.agentView) {
      final result = await _showDialog(AppStrings.CHANGE_TO_USER_TITLE.tr(), AppStrings.CHANGE_TO_USER_CONTENT.tr());
      if (!result) return;
      await getIt<AppSharedPreferences>().setString(AppStrings.view, AppStrings.cutomer);
      profileViewModel.navigateToScreen(LandingScreen.routeName);
    } else {
      final result = await _showDialog(AppStrings.CHANGE_TO_ANGEL_TITLE.tr(), AppStrings.CHANGE_TO_ANGEL_CONTENT.tr());
      if (!result) return;
      await getIt<AppSharedPreferences>().setString(AppStrings.view, AppStrings.agent);
      if (profileViewModel.user.verify != 0) {
        profileViewModel.navigateToScreen(LandingScreen.routeName);
      } else {
        profileViewModel.navigateToScreen(CourierVerifyScreen.routeName);
      }
    }
  }
}
