import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:storeangelApp/core/consts/appColors.dart';
import 'package:storeangelApp/core/consts/appConstants.dart';
import 'package:storeangelApp/core/consts/assetsPath.dart';
import 'package:storeangelApp/core/consts/sizeConfig.dart';
import 'package:storeangelApp/core/consts/text_styles.dart';
import 'package:storeangelApp/ui/shared/customCard.dart';

class UserDecideItem extends StatelessWidget {
  final String titleText;
  final String subtitleText;
  final Color colorButton;
  final double radius;
  final Color textColor;
  final double fontsize;
  final GestureTapCallback onPressed;
  final String image;
  final String itemButtonText;

  UserDecideItem({
    @required this.image,
    @required this.titleText,
    @required this.subtitleText,
    @required this.onPressed,
    this.itemButtonText,
    this.colorButton,
    this.radius,
    this.textColor,
    this.fontsize,
  }):assert(image!=null, 'Image is either not loading or you havent passed one to me');

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onPressed,
      child: CustomCard(
        margin: EdgeInsets.all(SizeConfig.screenHeight * 0.01),
        child: Container(
          padding: EdgeInsets.only(
              left: SizeConfig.screenWidth * 0.03,
              right: SizeConfig.screenWidth * 0.03,
              top: SizeConfig.screenHeight * 0.01,
              bottom: SizeConfig.screenHeight * 0.01),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(SizeConfig.introGetStarted_button_Radius),
          ),
          height: SizeConfig.screenHeight * 0.33,
          // width: double.infinity,
          child: Stack(
            children: <Widget>[
              Positioned.fill(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      child: Image.asset(
                        image,
                        height: SizeConfig.screenHeight * 0.14,
                        width: SizeConfig.screenWidth * 0.46,
                      ),
                    ),

                    SizeConfig.verticalSpaceMedium(),
                    Expanded(
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: SizeConfig.screenWidth*.06),
                        child: Column(
                          children: <Widget>[
                            FittedBox(
                              child: Text(
                                titleText,
                                style: AppStyles.BlackStyleWithBoldFont_24(context),
                                textAlign: TextAlign.center,maxLines: 1,

                              ),
                            ),
                            SizeConfig.verticalSpaceSmall(),
                            Expanded(
                              child: AutoSizeText(
                                subtitleText,
                                minFontSize: 8,
                                maxFontSize: SizeConfig.fontSizeMedium,
                                style: AppStyles.BlackStyleFont_20(context).copyWith(height: 1.4),
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    //  ),
                  ],
                ),
              ),
              Positioned(
                right: 0,
                top: 0,
                child: Container(
                  height: SizeConfig.screenWidth*0.13,
                  width: SizeConfig.screenWidth*0.13,
                  decoration: BoxDecoration(
                    color: AppColors.primaryColor,
                    borderRadius: BorderRadius.circular(SizeConfig.radiusSmall),
                  ),
                  child: Image.asset(AssetsPath.nextIcon,height:SizeConfig.screenHeight*0.00 ,width:SizeConfig.screenWidth*0.04 ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
