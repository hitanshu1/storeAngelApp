import 'package:flutter/material.dart';
import 'package:storeangelApp/core/consts/appColors.dart';
import 'package:storeangelApp/core/consts/appConstants.dart';
import 'package:storeangelApp/core/consts/sizeConfig.dart';
import 'package:storeangelApp/core/consts/text_styles.dart';
import 'package:storeangelApp/core/models/product.dart';
import 'package:storeangelApp/ui/shared/status_dot.dart';
import 'package:storeangelApp/ui/widgets/purchase/purchase_checkbox.dart';

class ViewSelectProductWidget extends StatefulWidget {
  final Product product;
  final bool selected;
  final Function onTap;

  ViewSelectProductWidget({this.product, this.onTap,this.selected:false});

  @override
  _ViewSelectProductWidgetState createState() => _ViewSelectProductWidgetState();
}

class _ViewSelectProductWidgetState extends State<ViewSelectProductWidget> {



  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: widget.onTap,
      child: Container(
        decoration: BoxDecoration(border: AppConstants.bottomBorder(context)),
        child: Padding(
          padding: SizeConfig.verticalLarPadding,
          child: Row(
            children: [
              PurchaseCheckBox(
                  status: widget.selected?PurchaseCheckBoxStatus.Selected:PurchaseCheckBoxStatus.Unselected),
              SizeConfig.horizontalSpaceSmall(),
              Expanded(
                child: RichText(
                  text: TextSpan(
                    text: '${widget.product.name} ',
                    style: AppStyles.BlackStyleFontWeight500_13(context).copyWith(
                      height: 1
                    ),

                  ),
                ),
              ),
              SizeConfig.horizontalSpaceSmall(),
              Text('${widget.product.quantity}', style: AppStyles.BlackStyleFontWeightSmall_12(context)),
              SizeConfig.horizontalSpaceSmall(),
              StatusDot(
                availableStatus: widget.product.availableStatus,
              )
            ],
          ),
        ),
      ),
    );
  }

}
