import 'package:flutter/material.dart';
import 'package:storeangelApp/core/consts/sizeConfig.dart';
import 'package:storeangelApp/core/consts/text_styles.dart';
import 'package:storeangelApp/ui/shared/apptextfield.dart';

class EmailPasswordWidget extends StatefulWidget {
  final Color colorBackground;
  final double radius;
  final Color textColor;
  final double fontSize;

  final TextInputAction textInputAction;
  final TextEditingController emailController;
  final TextEditingController passwordController;

  EmailPasswordWidget(
      {this.colorBackground,
      this.radius,
      this.textColor,
      this.fontSize,
      this.emailController,
        this.textInputAction,
      this.passwordController});

  @override
  _EmailPasswordWidgetState createState() => _EmailPasswordWidgetState();
}

class _EmailPasswordWidgetState extends State<EmailPasswordWidget> {
  final _emailFocusNode = FocusNode();
  final _passwordFocusNode = FocusNode();

  @override
  void dispose() {
    _emailFocusNode.dispose();
    _passwordFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          AppTextField(
            height: SizeConfig.screenHeight*.065,
            controller: widget.emailController,
            radius: SizeConfig.screenHeight*.02,
            focusNode: _emailFocusNode,
            hintText: 'Email',
            textInputAction: TextInputAction.next,
            nextFocusNode: _passwordFocusNode,
            hintextStyle: AppStyles.grayStyleFontWeight300_d02,
            keyboardType: TextInputType.emailAddress,
          ),

          SizeConfig.CVerticalSpaceSmallMedium(),
          AppTextField(
            height: SizeConfig.screenHeight*.065,
            controller: widget.passwordController,
            radius: SizeConfig.screenHeight*.02,
            focusNode: _passwordFocusNode,
            hintText: 'Password',
            obscureText: true,
            hintextStyle: AppStyles.grayStyleFontWeight300_d02,
            keyboardType: TextInputType.text,
            autoCorrect: false,

          ),

        ],
      ),
    );
  }
}
