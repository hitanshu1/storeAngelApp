import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:storeangelApp/core/consts/appConstants.dart';
import 'package:storeangelApp/core/consts/appString.dart';
import 'package:storeangelApp/core/consts/sizeConfig.dart';
import 'package:storeangelApp/core/services/statusbar_service.dart';
import 'package:storeangelApp/core/viewmodel/viewmodel_home_first_use.dart';
import 'package:storeangelApp/ui/shared/app_header.dart';
import 'package:storeangelApp/ui/shared/base_model.dart';
import 'package:storeangelApp/ui/shared/base_view.dart';
import 'package:storeangelApp/ui/shared/customScaffold.dart';
import 'package:storeangelApp/ui/shared/premium_card.dart';
import 'package:storeangelApp/ui/widgets/courier/view_courier_order_widget.dart';

class HomeFirstUseScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      body: BaseView<HomeFirstUseViewModel>(
        onModelReady: (model) => model.getAssignOrderList('courierId'),
        builder: (context, model, child) {
          if (model.state == ViewState.Busy) {
            return AppConstants.circulerProgressIndicator();
          } else {
            return ListView.builder(
                padding: SizeConfig.topAppbarPadding,
                itemCount: model.assignOrders.length + 2,
                itemBuilder: (context, int index) {
                  if (index == 0) {
                    return  Padding(
                      padding: SizeConfig.sidepadding,
                      child: AppHeader(
                        title:'Hi, Jorge!' ,
                        subtitle:AppStrings.HERE_ARE_ALL_YOUR_PUBLISHED_REQUESTS.tr() ,

                      ),
                    );
                  } else if (index == model.assignOrders.length + 1) {
                    return _premiumAd(context);
                  }

                  index -= 1;
                  return Padding(
                    padding: SizeConfig.sidepadding,
                    child: InkWell(
                      child: ViewCourierOrderWidget(
                        order: model.assignOrders[index],
                      ),
                      onTap: () async {
                        StatusBarService.changeStatusBarColor(StatusBarType.OffGray, context);
                        await model.navigatetoOrderInformationScreen(index);
                        StatusBarService.changeStatusBarColor(StatusBarType.Dark, context);
                      },
                    ),
                  );
                });
          }
        },
      ),
    );
  }

  Widget _premiumAd(BuildContext context) {
    return Padding(
      padding: SizeConfig.sidepadding,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          PremiumCard(
            title: AppStrings.GET_PREMIUM_NOW.tr(),
            subtitle: AppStrings.PREMIUM_SUBTITLE_MORE_EVERYTHING.tr(),
          ),
          SizeConfig.verticalSpace(SizeConfig.bottomPadding.bottom),
        ],
      ),
    );
  }
}
