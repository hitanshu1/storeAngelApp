import 'package:auto_size_text/auto_size_text.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:storeangelApp/core/consts/appColors.dart';
import 'package:storeangelApp/core/consts/appConstants.dart';
import 'package:storeangelApp/core/consts/appString.dart';
import 'package:storeangelApp/core/consts/sizeConfig.dart';
import 'package:storeangelApp/core/consts/storeangel_icons_icons.dart';
import 'package:storeangelApp/core/consts/text_styles.dart';
import 'package:storeangelApp/core/models/order.dart';
import 'package:storeangelApp/core/services/date_format_service.dart';
import 'package:storeangelApp/core/services/string_service.dart';
import 'package:storeangelApp/core/viewmodel/viewmodel_view_courier_order.dart';
import 'package:storeangelApp/ui/shared/base_view.dart';
import 'package:storeangelApp/ui/shared/customCard.dart';
import 'package:storeangelApp/ui/shared/custom_divider_widget.dart';
import 'package:storeangelApp/ui/shared/deliveryinfo_rowWidget.dart';

class ViewCourierOrderWidget extends StatelessWidget {
  final OrderOrPurchases order;
  final bool submitProposal;

  ViewCourierOrderWidget({this.order, this.submitProposal: false});

  @override
  Widget build(BuildContext context) {
    return BaseView<ViewCourierOrderViewModel>(
      builder: (context, model, child) {
        return Padding(
          padding: EdgeInsets.only(bottom: SizeConfig.bottomPadding.bottom),
          child: CustomCard(
            child: Padding(
              padding: SizeConfig.verticalPadding,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizeConfig.VerticalSpaceSmallMedium(),
                  Padding(
                    padding: SizeConfig.sidepadding,
                    child: Row(
                      children: [
                        Expanded(
                            child: Text(
                              order.storeDetails.name,
                              style: AppStyles.BlackStyleWithBold600Font_20(context),
                            )),
                        SizeConfig.horizontalSpaceSmall(),
                        Expanded(
                            child: Text(order.clientDetails.name, style: AppStyles.BlackStyleWithBold600Font_20(context)))
                      ],
                    ),
                  ),
                  SizeConfig.verticalSpaceSmall(),
                  Padding(
                    padding: SizeConfig.sidepadding,
                    child: Row(
                      children: [
                        Expanded(
                            child: Text(
                              order.storeDetails.fullAddress,
                              style: AppStyles.GrayStyle_Font16(context), textAlign: TextAlign.start,
                            )),
                        SizeConfig.horizontalSpaceSmall(),
                        Expanded(
                          child: Text(order.clientDetails.addressLine, style: AppStyles.GrayStyle_Font16(context), textAlign: TextAlign.start),
                        ),
                      ],
                    ),
                  ),
                  SizeConfig.verticalSpace(SizeConfig.VerticalSpaceMedium*0.7),
                  Padding(
                    padding: SizeConfig.sidepadding,
                    child: Row(
                      children: [
                        Expanded(
                          child: InkWell(
                            onTap: () {
                              model.toggleView();
                            },
                            child: Text(
                              '${order.purchaseDetails.products.length} ${AppStrings.ITEMS.tr()}',
                              style: AppStyles.BlackStyleFont_16(context),
                            ),
                          ),
                        ),
                        SizeConfig.horizontalSpaceSmall(),
                        Expanded(
                            child: Text(
                          '6 ${AppStrings.PUBLISHED.tr()}',
                          style: AppStyles.BlackStyleFont_16(context),
                        ))
                      ],
                    ),
                  ),
                  Padding(
                    padding: SizeConfig.sidepadding,
                    child: InkWell(
                      onTap: model.toggleView,
                      child: SizedBox(
                        height: 4,
                        width: SizeConfig.screenWidth*.3,
                      ),
                    ),
                  ),
                  Padding(
                    padding: SizeConfig.sidepadding,
                    child: Row(
                      children: [
                        Expanded(
                          child: InkWell(
                            onTap: () {
                              model.toggleView();
                            },
                            child: model.viewDetails
                                ? Text(
                                  AppStrings.CLOSE.tr(),
                                  style: AppStyles.GreenStyleWith_Font16(context),
                                )
                                : Text(
                                  AppStrings.VIEW.tr(),
                                  style: AppStyles.GreenStyleWith_Font16(context),
                                ),
                          ),
                        ),
                        SizeConfig.horizontalSpaceSmall(),
                        Expanded(
                            child: Text(
                          '4${order.alreadyDone > 0 ? ' (' + order.alreadyDone.toString() + ')' : ''} ${AppStrings.COMPLETED.tr()}',
                          style: AppStyles.GreenStyleWith_Font16(context),
                        ))
                      ],
                    ),
                  ),
                  model.viewDetails
                      ? Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizeConfig.verticalSpaceSmall(),
                            CustomDividerWidget(
                              height: 1,
                            ),
                            SizeConfig.verticalSpaceSmall(),
                            Padding(
                              padding: SizeConfig.sidepadding,
                              child: DeliveryInfoRowWidget(
                                  hasBorderColor: false,
                                  enablePadding: false,
                                  firstText: AppStrings.DELIVERY_DATE.tr()+':',
                                  secondText: DateFormatService.getDateFormatDDMMM(order.deliveredAt.toString(), context)+' '+order.timeDuration),
                            ),
                            SizeConfig.verticalSpaceSmall(),
                            Padding(
                              padding: SizeConfig.sidepadding,
                              child: DeliveryInfoRowWidget(
                                firstText: AppStrings.ORDER_PAYMENT.tr()+':',
                                secondText: AppStrings.PREPAYMENT.tr(),
                                hasBorderColor: false,
                                enablePadding: false,
                              ),
                            ),
                            SizeConfig.verticalSpaceSmall(),
                            Padding(
                              padding: SizeConfig.sidepadding,
                              child: Text(
                                AppStrings.COMMENT.tr()+':',
                                style: AppStyles.GrayStyle_Font12(context),
                              ),
                            ),
                            SizeConfig.verticalSpaceSmall(),
                            Padding(
                              padding: SizeConfig.sidepadding,
                              child: Text(
                                'When you deliver, please do not ring the bell. My baby can sleep. Just call me and I’ll meet you.',
                                style: AppStyles.BlackStyleFontWeightSmall_12(context),
                              ),
                            ),
                            SizeConfig.verticalSpaceSmall(),
                            CustomDividerWidget(
                              height: 1,
                            ),

                          ],
                        )
                      : Container(),
                  SizeConfig.verticalSpaceSmall(),
                  Padding(
                    padding: SizeConfig.sidepadding,
                    child: Container(
                      decoration: BoxDecoration(
                          color: Theme.of(context).toggleableActiveColor,
                          borderRadius: BorderRadius.circular(AppConstants.ContainerRoundCorner_Radius)),
                      padding: EdgeInsets.only(
                        top: SizeConfig.screenWidth * .05,
                        bottom: SizeConfig.screenWidth * .05
                      ),
                      child: Column(
                        children: [
                          Padding(
                            padding: SizeConfig.sidepadding,
                            child: Row(
                              children: [
                                Expanded(
                                    child: Text(StringService.getCourierBudgetName(order.purchaseDetails).name+':',
                                  style: AppStyles.BlackStyleWithw500_FontC18(context).copyWith(
                                    fontSize: SizeConfig.fontSizeMedium
                                  ),
                                )),
                                Text('${AppStrings.euro+' '}${AppConstants.priceAfterConvert(order.orderAmount)}',
                                    style: AppStyles.BlackStyleWithw500_FontC18(context))
                              ],
                            ),
                          ),
                          SizeConfig.verticalSpaceSmall(),
                          CustomDividerWidget(
                            height: 1,
                          ),

                          SizeConfig.verticalSpaceSmall(),
                          Padding(
                            padding: SizeConfig.sidepadding,
                            child: Row(
                              children: [
                                Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.only(right: 6),
                                    child: AutoSizeText(
                                      '10 ${AppStrings.OFFERS.tr()}',
                                      style: AppStyles.GrayStyle_FontMedium(context),
                                      minFontSize: 10,
                                      maxFontSize: AppStyles.GrayStyle_FontMedium(context).fontSize,
                                      maxLines: 1,
                                    ),
                                  ),
                                ),
                                Expanded(
                                  flex: 2,
                                  child: Align(
                                    alignment: Alignment.centerRight,
                                    child: FittedBox(
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        mainAxisAlignment: MainAxisAlignment.end,
                                        children: [
                                          Icon(
                                            StoreangelIcons.verified_icon,
                                            color: Theme.of(context).primaryColor,
                                            size: SizeConfig.fontSizeLarge,
                                          ),
                                          SizeConfig.horizontalSpace(6),
                                          Text(
                                            AppStrings.SUBMIT_OFFER.tr(),
                                            style: AppStyles.GreenStyleWithBold800_Font20(context).copyWith(fontWeight: FontWeight.bold),
                                            textAlign: TextAlign.end,
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizeConfig.verticalSpaceSmall(),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
