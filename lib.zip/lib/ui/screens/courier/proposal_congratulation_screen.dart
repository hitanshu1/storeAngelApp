//import 'package:flutter/material.dart';
//import 'package:storeangelApp/MyUtils.dart';
//import 'package:storeangelApp/core/consts/appConstants.dart';
//import 'package:storeangelApp/core/consts/appString.dart';
//import 'package:storeangelApp/core/consts/assetsPath.dart';
//import 'package:storeangelApp/core/consts/sizeConfig.dart';
//import 'package:storeangelApp/core/consts/text_styles.dart';
//import 'package:storeangelApp/core/services/statusbar_service.dart';
//import 'package:storeangelApp/core/viewmodel/viewmodel_proposalcongratulation.dart';
//import 'package:storeangelApp/ui/screens/courier/readytowork_modal_screen.dart';
//import 'package:storeangelApp/ui/shared/base_model.dart';
//import 'package:storeangelApp/ui/shared/base_view.dart';
//import 'package:storeangelApp/ui/shared/button_widget.dart';
//import 'package:storeangelApp/ui/widgets/courier/courier_order_details_widget.dart';
//import 'package:easy_localization/easy_localization.dart';
//
//class ProposalCongratulationScreen extends StatelessWidget {
//  @override
//  Widget build(BuildContext context) {
//    StatusBarService.changeStatusBarColor(StatusBarType.Gray, context);
//    return BaseView<ProposalCongratulationViewModel>(
//      onModelReady: (model)=>model.getOrder('courierId'),
//      builder: (context,model,child){
//        return Scaffold(
//          body: model.state==ViewState.Busy?AppConstants.circulerProgressIndicator():
//          SingleChildScrollView(
//            child: Column(
//              children: [
//                SizeConfig.CVerticalSpaceBigger(),
//                SizedBox(
//                  height: SizeConfig.imageHeight140,
//                    child: Image.asset(AssetsPath.circular_border_success)),
//                SizeConfig.CVerticalSpaceSmallMedium(),
//                Text(AppStrings.CONGRATULATION.tr(),style: AppStyles.GreenStyleWithBold700Font_36(context),),
//                SizeConfig.CVerticalSpaceMedium(),
//                SizedBox(
//                  width: SizeConfig.screenWidth*.85,
//                  child: Text(AppStrings.BERNARD_FLORES_HAS_ACCEPT.tr(),
//                  style: AppStyles.BlackStyleNormal_FontC18(context),textAlign: TextAlign.center,),
//                ),
//                SizeConfig.CVerticalSpaceBig43(),
//                Padding(
//                  padding:  SizeConfig.sidepadding,
//                  child: ButtonWidget(onPressed: (){
//                    MyUtils.showAppDialog(context: context,child:
//                    ReadyToWorkModalScreen(order: model.order,));
//                  },buttonText: AppStrings.YES_I_GOT_THE_PAYMENT_ON_PAYPAL.tr(),
//                    fontSize: SizeConfig.fontSizeLarge,
//                  buttonColor: Theme.of(context).primaryColor,
//                  radius: AppConstants.button_Radius,),
//                ),
//                SizeConfig.CVerticalSpaceBig(),
//                SizedBox(
//                  width: SizeConfig.screenWidth*.65,
//                  child: Text(AppStrings.IN_CASE_YOU_DON0T_GET_IT.tr(),
//                  style: AppStyles.GrayStyle_Font20,textAlign: TextAlign.center,),
//                ),
//                SizeConfig.CVerticalSpaceMedium(),
//                Text(AppStrings.I_DON0T_GOT_MONEY_ON_MY_PAYPAL_ACCOUNT.tr(),
//                style: AppStyles.GreenStyleWithBold800_Font20(context),),
//                SizeConfig.CVerticalSpaceBig(),
//                Padding(
//                  padding: SizeConfig.sidepadding,
//                  child: CourierOrderDetails(order: model.order,),
//                ),
//                SizeConfig.CVerticalSpaceMedium(),
//              ],
//            ),
//          ),
//        );
//      },
//    );
//  }
//}
