//import 'package:flutter/cupertino.dart';
//import 'package:flutter/material.dart';
//import 'package:storeangelApp/core/consts/appColors.dart';
//import 'package:storeangelApp/core/consts/appConstants.dart';
//import 'package:storeangelApp/core/consts/appString.dart';
//import 'package:storeangelApp/core/consts/sizeConfig.dart';
//import 'package:storeangelApp/core/consts/text_styles.dart';
//import 'package:storeangelApp/core/models/order.dart';
//import 'package:storeangelApp/core/viewmodel/viewmodel_readytowork.dart';
//import 'package:storeangelApp/ui/screens/courier/current_order_screen.dart';
//import 'package:storeangelApp/ui/shared/base_view.dart';
//import 'package:storeangelApp/ui/shared/button_widget.dart';
//import 'package:easy_localization/easy_localization.dart';
//class ReadyToWorkModalScreen extends StatelessWidget {
//  final OrderOrPurchases order;
//  ReadyToWorkModalScreen({this.order});
//  @override
//  Widget build(BuildContext context) {
//    return BaseView<ReadyToWorkViewModel>(
//      builder: (context,model,child){
//        return Container(
//          width: SizeConfig.screenWidth,
//          decoration: new BoxDecoration(
//            shape: BoxShape.rectangle,
//            borderRadius: new BorderRadius.all(new Radius.circular(50.0)),
//          ),
//          child: Column(
//            mainAxisSize: MainAxisSize.min,
//            children: [
//              SizeConfig.CVerticalSpaceBig(),
//              SizedBox(
//                  width: SizeConfig.screenWidth*.7,
//                  child: Text(AppStrings.LETS_CUSTOMERS_KNOWS_IF_READY.tr(),
//                    style: AppStyles.BlackStyleWithBold800Font_24(context).copyWith(fontSize: SizeConfig.fontSizeLarge+4),textAlign: TextAlign.center,
//                  )),
//              SizeConfig.CVerticalSpacevEMedium(),
//              Padding(
//                padding: SizeConfig.sidepadding,
//                child: Text(AppStrings.WHEN_READY_TO_WORK_STATUS.tr(),
//                  style: AppStyles.BlackStyleFont_20(context),textAlign: TextAlign.center,),
//              ),
//              SizeConfig.CVerticalSpacevEMedium(),
//              Divider(
//                color: AppColors.lightGreyColor,
//              ),
//              SizeConfig.CVerticalSpacevEMedium(),
//              CupertinoSwitch(value: model.readyToWorkValue, onChanged: (value){
//                model.updateReadyToWorkValue(value);
//              },activeColor: Theme.of(context).primaryColor,),
//              SizeConfig.CVerticalSpaceMedium(),
//              Text(AppStrings.READY_TO_WORK.tr(),style: AppStyles.BlackStyleFont_20(context),),
//              SizeConfig.CVerticalSpacevEMedium(),
//              Padding(
//                padding: SizeConfig.sidepadding,
//                child: ButtonWidget(onPressed: (){
//                  model.navigateToScreen(CurrentOrderScreen.routeName,context,arguments: order);
//                },buttonColor: Theme.of(context).primaryColor,
//                  radius: AppConstants.button_Radius,
//                  buttonText: AppStrings.OK.tr(),fontSize: SizeConfig.fontSizeLarge,),
//              ),
//              SizeConfig.CVerticalSpaceBig(),
//
//            ],
//          ),
//        );
//      },
//    );
//  }
//}
