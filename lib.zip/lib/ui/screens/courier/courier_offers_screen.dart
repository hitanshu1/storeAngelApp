import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:storeangelApp/core/consts/appColors.dart';
import 'package:storeangelApp/core/consts/appConstants.dart';
import 'package:storeangelApp/core/consts/appString.dart';
import 'package:storeangelApp/core/consts/sizeConfig.dart';
import 'package:storeangelApp/core/consts/text_styles.dart';
import 'package:storeangelApp/core/viewmodel/viewmodel_courier_offers.dart';
import 'package:storeangelApp/ui/shared/app_header.dart';
import 'package:storeangelApp/ui/shared/base_model.dart';
import 'package:storeangelApp/ui/shared/base_view.dart';
import 'package:storeangelApp/ui/shared/customScaffold.dart';
import 'package:storeangelApp/ui/widgets/courier/single_offer_screen.dart';
import 'package:storeangelApp/ui/widgets/courier_offers/order_accepted_widget.dart';
import 'package:storeangelApp/ui/widgets/courier_offers/view_offer_order_widget.dart';
class CourierOfferScreen extends StatefulWidget {

  @override
  _CourierOfferScreenState createState() => _CourierOfferScreenState();
}

class _CourierOfferScreenState extends State<CourierOfferScreen> {
  final ScrollController _scrollController = ScrollController();
  
  @override
  void dispose() {
    super.dispose();
    _scrollController.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    return BaseView<CourierOffersViewModel>(
      onModelReady: (courierOffersViewModel)=>courierOffersViewModel.initialize(_scrollController),
      builder: (context,courierOffersViewModel,child){
        if(courierOffersViewModel.state==ViewState.Busy){
          return CustomScaffold(
              backgroundColor: Theme.of(context).backgroundColor,
              body: AppConstants.circulerProgressIndicator());
        }else{
          return CustomScaffold(
            body: ListView.builder(
              controller: _scrollController,
                padding: SizeConfig.topAppbarPadding,
                itemCount: courierOffersViewModel.offerOrders.length+1,
                itemBuilder: (context,int index){
                if(index==0){
                  return Padding(
                    padding: SizeConfig.sidepadding,
                    child: AppHeader(
                      title:AppStrings.MY_OFFERS.tr() ,
                      subtitle:AppStrings.CHECK_THE_CURRENT_STATUS_AND_DETAILS.tr() ,

                    ),
                  );
                }
                  return Padding(
                    padding: SizeConfig.sidepadding.copyWith(bottom: SizeConfig.bottomPadding.bottom),
                    child: InkWell(
                      child:  ViewOfferOrderWidget(order: courierOffersViewModel.offerOrders[index-1],),
                      onTap: (){
                        courierOffersViewModel.navigateTo(SingleOfferScreen.routeName, courierOffersViewModel.offerOrders[index-1], context);
                      },),
                  );
                }),
          );
        }
      },
    );
  }

  Widget orderAccepted(BuildContext context,int accepted){
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [

        SizeConfig.CVerticalSpaceSmallMediumC12(),
        OrderAcceptedWidget(
          title: AppStrings.ORDER_ACCEPTED.tr(),
          subtitle: '$accepted '+AppStrings.ORDER_ACCEPTED_AND_TRANSFER.tr(),
          padding: EdgeInsets.only(bottom: 3,
            left: 10,right: 10,top: 3,
          ),
          imageHeight: SizeConfig.mediumImageheight,
          titleStyle: AppStyles.GreenStyleWithBoldFont_C20(context),
          subtitleStyle: AppStyles.BlackStyleWithBold500Font_14(context),
        ),

        SizeConfig.CVerticalSpaceSmallMediumC12(),
      ],
    );
  }
}
