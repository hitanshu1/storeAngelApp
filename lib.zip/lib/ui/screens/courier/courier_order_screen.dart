import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:storeangelApp/core/consts/appConstants.dart';
import 'package:storeangelApp/core/consts/appString.dart';
import 'package:storeangelApp/core/consts/sizeConfig.dart';
import 'package:storeangelApp/core/consts/storeangel_icons_icons.dart';
import 'package:storeangelApp/core/consts/text_styles.dart';
import 'package:storeangelApp/core/enums/order_purchase_status.dart';
import 'package:storeangelApp/core/services/statusbar_service.dart';
import 'package:storeangelApp/core/viewmodel/viewmodel_courier_order.dart';
import 'package:storeangelApp/ui/screens/courier/courier_order_delivered_screen.dart';
import 'package:storeangelApp/ui/shared/app_header.dart';
import 'package:storeangelApp/ui/shared/base_model.dart';
import 'package:storeangelApp/ui/shared/base_view.dart';
import 'package:storeangelApp/ui/shared/customCard.dart';
import 'package:storeangelApp/ui/shared/customScaffold.dart';
import 'package:storeangelApp/ui/shared/custom_divider_widget.dart';
import 'package:storeangelApp/ui/shared/view_app_Image.dart';
import 'package:storeangelApp/ui/shared/view_courier_order_status_widget.dart';
import 'package:storeangelApp/ui/widgets/courier/courier_common_order_text_row.dart';
import 'package:storeangelApp/ui/widgets/courier/courier_order/courier_order_bottom_widget.dart';
import 'package:storeangelApp/ui/widgets/courier/courier_order/order_package_list_and_past_order_widget.dart';
import 'package:storeangelApp/ui/widgets/courier_order/courier_completed_order_widget.dart';
import 'package:storeangelApp/ui/widgets/orderDelivered/order_status_row_widget.dart';

import 'courier_order/courier_order_delivered_summary_screen.dart';

class CourierOrderScreen extends StatefulWidget {
  @override
  _CourierOrderScreenState createState() => _CourierOrderScreenState();
}

class _CourierOrderScreenState extends State<CourierOrderScreen> {
  final ScrollController _scrollController = ScrollController();

  @override
  void dispose() {
    super.dispose();
    _scrollController.dispose();
  }

  @override
  Widget build(BuildContext context) {

    StatusBarService.changeStatusBarColor(StatusBarType.Gray, context);
    return BaseView<CourierOrderViewModel>(
      onModelReady: (courierOrderViewModel) => courierOrderViewModel.initialize(_scrollController),
      builder: (context, courierOrderViewModel, child) {
        if (courierOrderViewModel.state == ViewState.Busy) {
          return CustomScaffold(
              backgroundColor: Theme.of(context).backgroundColor,
              body: AppConstants.circulerProgressIndicator());
        }
        return CustomScaffold(
          body: CustomScrollView(
            controller: _scrollController,
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: SizeConfig.sidepadding.copyWith(
                    top: SizeConfig.topAppbarPadding.top
                  ),
                  child: AppHeader(
                    title:AppStrings.YOUR_ORDERS.tr() ,
                    subtitle:AppStrings.HERE_ARE_YOUR_ORDERS.tr() ,

                  ),
                ),
              ),
              SliverPadding(
                padding: EdgeInsets.fromLTRB(SizeConfig.sidepadding.left, SizeConfig.verticalC13Padding.top,
                    SizeConfig.sidepadding.right, SizeConfig.screenHeight * .02),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate(
                      (context,int index){
                        return Padding(
                          padding: SizeConfig.bottomPadding,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              InkWell(
                                onTap: () {
                                  if (courierOrderViewModel.orders[index].status != OrderPurchaseStatus.OrderDelivered) {
                                    courierOrderViewModel.navigateToScreen(CourierOrderDeliveredScreen.routeName, context,
                                        arguments: CourierOrderDeliveredScreenArgument(
                                            order: courierOrderViewModel.orders[index], initialIndex: 0));
                                  } else {
                                    courierOrderViewModel.navigateToScreen(
                                        CourierOrderDeliveredSummaryScreen.routeName, context,
                                        arguments: courierOrderViewModel.orders[index]);
                                  }
                                },
                                child: CustomCard(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      SizeConfig.verticalSpaceMedium(),
                                      Padding(
                                        padding: SizeConfig.sidepadding,
                                        child: DecoratedBox(
                                          decoration: BoxDecoration(
                                              color: Theme.of(context).toggleableActiveColor,
                                              borderRadius: BorderRadius.circular(AppConstants.ContainerRoundCorner_Radius)),
                                          child: Padding(
                                            padding: SizeConfig.sidepadding,
                                            child: Column(
                                              children: [
                                                SizeConfig.verticalSpaceMedium(),
                                                Padding(
                                                  padding: SizeConfig.sidepadding,
                                                  child: ViewCourierOrderStatusWidget(
                                                    order: courierOrderViewModel.orders[index],
                                                  ),
                                                ),
                                                SizeConfig.verticalSpaceSmall(),
                                                Padding(
                                                  padding: SizeConfig.sidepadding,
                                                  child: OrderStatusRowWidget(
                                                    status: courierOrderViewModel.orders[index].status,
                                                  ),
                                                ),
                                                SizeConfig.verticalSpaceMedium(),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      SizeConfig.verticalSpaceSmall(),
                                      SizeConfig.verticalSpaceMedium(),
                                      Padding(
                                        padding: SizeConfig.sidepadding,
                                        child: Row(
                                          children: [
                                            Expanded(
                                                child: Row(
                                                  children: [
                                                    ViewAppImage(
                                                      imageUrl: courierOrderViewModel.orders[index].storeDetails.image,
                                                      height: SizeConfig.smallerImageHeight,
                                                      width: SizeConfig.smallerImageHeight,
                                                      radius: 10,
                                                    ),
                                                  ],
                                                )),
                                            SizeConfig.horizontalSpaceSmall(),
                                            Expanded(
                                              child: Row(
                                                children: [
                                                  ViewAppImage(
                                                    imageUrl: courierOrderViewModel.orders[index].clientDetails.imageUrl,
                                                    height: SizeConfig.smallerImageHeight,
                                                    width: SizeConfig.smallerImageHeight,
                                                    radius: SizeConfig.smallerImageHeight,
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      SizeConfig.verticalSpaceSmall(),
                                      Padding(
                                        padding: SizeConfig.sidepadding,
                                        child: CourierCommonOrderTextRowWidget(
                                          firstText: courierOrderViewModel.orders[index].storeDetails.name,
                                          firstTextSyle: AppStyles.BlackStyleWithBold600Font_20(context),
                                          secondTextStyle: AppStyles.BlackStyleWithBold600Font_20(context),
                                          secondText: courierOrderViewModel.orders[index].clientDetails.name,
                                        ),
                                      ),
                                      SizeConfig.CVerticalSpaceVarySmall(),
                                      Padding(
                                        padding: SizeConfig.sidepadding,
                                        child: CourierCommonOrderTextRowWidget(
                                          firstText: courierOrderViewModel.orders[index].storeDetails.fullAddress,
                                          secondText: courierOrderViewModel.orders[index].clientDetails.addressLine,
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsets.fromLTRB(SizeConfig.sidepadding.left,
                                            SizeConfig.screenHeight * .013, SizeConfig.sidepadding.right, 0),
                                        child: CourierCommonOrderTextRowWidget(
                                          firstChild: Text('10 ${AppStrings.ITEMS.tr()} '),
                                          secondChild: Row(
                                            children: [
                                              Stack(
                                                children: [
                                                  InkWell(
                                                    child: Padding(
                                                      padding: const EdgeInsets.all(6.0),
                                                      child: Icon(StoreangelIcons.message_icon,
                                                          color: Theme.of(context).focusColor),
                                                    ),
                                                    onTap: () {
                                                      courierOrderViewModel.navigateToScreen(
                                                          CourierOrderDeliveredScreen.routeName, context,
                                                          arguments: CourierOrderDeliveredScreenArgument(
                                                              order: courierOrderViewModel.orders[index], initialIndex: 1));
                                                    },
                                                  ),
                                                  Positioned.fill(
                                                    child: Align(
                                                      alignment: Alignment.topRight,
                                                      child: Text(
                                                        '1',
                                                        style: Theme.of(context).textTheme.subtitle2,
                                                      ),
                                                    ),
                                                  )
                                                ],
                                              )
                                            ],
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: SizeConfig.sidepadding,
                                        child: CustomDividerWidget(),
                                      ),
                                      CourierOrderBottomWidget(
                                        order: courierOrderViewModel.orders[index],
                                        model: courierOrderViewModel,
                                        index: index,
                                      ),
                                      SizeConfig.verticalSpaceMedium(),

                                    ],
                                  ),
                                ),
                              ),

                            ],
                          ),
                        );
                      },childCount: courierOrderViewModel.orders.length
                  ),
                ),
              ),

              courierOrderViewModel.orders.first.status != OrderPurchaseStatus.OrderDelivered
                  ? SliverPadding(
                padding: EdgeInsets.fromLTRB(SizeConfig.sidepadding.left, SizeConfig.screenHeight * .02,
                    SizeConfig.sidepadding.right, 0),
                sliver: SliverList(delegate: SliverChildListDelegate([
                Text(
                    AppStrings.PACKAGE_LIST.tr() ,
                    style: AppStyles.GreenStyleWithBoldFont_C20(context),
                ),
                SizeConfig.verticalSpaceMedium(),
                OrderPackageListAndPastOrderWidget(
                    order: courierOrderViewModel.orders.first,
                    model: courierOrderViewModel,
                )
              ])),
                  ) :SliverToBoxAdapter(),
            SliverPadding(
                      padding: EdgeInsets.fromLTRB(SizeConfig.sidepadding.left, SizeConfig.screenHeight * .02,
                          SizeConfig.sidepadding.right, 0),
                      sliver: SliverList(
                          delegate: SliverChildListDelegate([
                        SizeConfig.verticalSpaceMedium(),
                        Text(
                          AppStrings.PAST_ORDERS.tr(),
                          style: AppStyles.GreenStyleWithBoldFont_C20(context),
                        ),
                        SizeConfig.verticalSpaceMedium(),
                      ])),
                    ),
              SliverPadding(
                      padding: EdgeInsets.fromLTRB(SizeConfig.sidepadding.left, 0, SizeConfig.sidepadding.right,
                          SizeConfig.screenHeight * .02),
                      sliver: SliverList(
                        delegate: SliverChildBuilderDelegate(
                            (context, index) => CourierCompletedOrderWidget(
                                  order: courierOrderViewModel.pastedOrders[index],
                                  model: courierOrderViewModel,
                                ),
                            childCount: courierOrderViewModel.pastedOrders.length),
                      ),
                    )
              ,
            ],
          ),
        );
      },
    );
  }
}
