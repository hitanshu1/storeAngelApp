import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:storeangelApp/core/consts/appColors.dart';
import 'package:storeangelApp/core/consts/appConstants.dart';
import 'package:storeangelApp/core/consts/appString.dart';
import 'package:storeangelApp/core/consts/assetsPath.dart';
import 'package:storeangelApp/core/consts/sizeConfig.dart';
import 'package:storeangelApp/core/consts/storeangel_icons_icons.dart';
import 'package:storeangelApp/core/consts/text_styles.dart';
import 'package:storeangelApp/core/models/address.dart';
import 'package:storeangelApp/core/models/payment_option.dart';
import 'package:storeangelApp/core/models/places_all_model.dart';
import 'package:storeangelApp/core/models/purchase_deatails.dart';
import 'package:storeangelApp/core/models/user.dart';
import 'package:storeangelApp/core/services/statusbar_service.dart';
import 'package:storeangelApp/core/viewmodel/deliverylocation_viewmodel.dart';
import 'package:storeangelApp/ui/shared/base_model.dart';
import 'package:storeangelApp/ui/shared/base_view.dart';
import 'package:storeangelApp/ui/shared/bottomsheet_search_view.dart';
import 'package:storeangelApp/ui/shared/button_widget.dart';
import 'package:storeangelApp/ui/shared/circleIcon.dart';
import 'package:storeangelApp/ui/shared/clipper/slider_clipper.dart';
import 'package:storeangelApp/ui/shared/customSliverAppBar.dart';
import 'package:storeangelApp/ui/shared/custom_flexible_space_widget.dart';
import 'package:storeangelApp/ui/shared/showbottomSheet.dart';
import 'package:storeangelApp/ui/widgets/order_by_store/deliverylocation/delevery_location_checkbox.dart';
import 'package:storeangelApp/ui/widgets/order_by_store/deliverylocation/singleline_selectable_option.dart';
import 'package:storeangelApp/ui/widgets/share/custom_date_picker.dart';

class DeliveryLocationScreen extends StatefulWidget {
  static const String routeName = 'deliveryLocationScreen';
  final PurchaseDetails purchaseDetails;

  DeliveryLocationScreen({this.purchaseDetails});

  @override
  _DeliveryLocationScreenState createState() => _DeliveryLocationScreenState();
}

class _DeliveryLocationScreenState extends State<DeliveryLocationScreen> {
  var _radius = SizeConfig.radiusOfSliverAppbar;
  ScrollController _scrollController = ScrollController();
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  FocusNode _commentNode = FocusNode();

  @override
  void initState() {
    super.initState();

    _scrollController.addListener(() {
      if (_isAppBarExpanded) {
        setState(() {
          _radius = 0.0;
        });
      } else {
        setState(() {
          _radius = SizeConfig.radiusOfSliverAppbar;
        });
      }
    });
  }

  bool get _isAppBarExpanded {
    return _scrollController.hasClients && _scrollController.offset > (200 - kToolbarHeight);
  }

  @override
  void dispose() {
    super.dispose();
    _scrollController.dispose();
    _commentNode.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Future.delayed(
        Duration(milliseconds: 300), () => StatusBarService.changeStatusBarColor(StatusBarType.Light, context));
    return BaseView<DeliveryLocationViewModel>(
      onModelReady: (deliveryLocationViewModel) {
        deliveryLocationViewModel.getAddress(UserModel(), widget.purchaseDetails);
        deliveryLocationViewModel.init(_commentNode);
      },
      builder: (context, deliveryLocationViewModel, child) {
        return Scaffold(
          key: _scaffoldKey,
          body: deliveryLocationViewModel.state == ViewState.Busy
              ? AppConstants.circulerProgressIndicator()
              : CustomScrollView(
            controller: _scrollController,
            slivers: [
              CustomSliverAppBar(
                backgroundColor: Theme
                    .of(context)
                    .cardColor,
                pinned: true,
                floating: true,
                leading: BackButton(
                  color: Theme
                      .of(context)
                      .iconTheme
                      .color,
                  onPressed: () {
                    deliveryLocationViewModel.navigatorPop();
                  },
                ),
                title: Text(
                 '${AppStrings.TERMS_AND_CONDITIONS.tr()}',
                  style: AppStyles.BlackStyleWithBold800Font_24(context),
                ),
                centerTitle: true,
                shape: ContinuousRectangleBorder(
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(_radius), bottomRight: Radius.circular(_radius))),
                flexibleSpace: FlexibleSpaceBar(
                  background: CustomFlexibleSpaceWidget(
                    scrollController: _scrollController,
                    child: Container(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(
                            height: SizeConfig.screenHeight * .12,
                          ),
                          Spacer(),
                          Padding(
                            padding: SizeConfig.sidepadding,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                CircleIcon(
                                  svgAsset: AssetsPath.svgSelectProduct,
                                  backgroundColor: AppColors.lightGrayLittleColor,
                                  iconColor: AppColors.black,
                                ),
                                Container(
                                  height: 5,
                                  width: SizeConfig.screenWidth * .13,
                                  color: AppColors.lightGrayLittleColor,
                                ),
                                Flexible(
                                  child: ClipPath(
                                    clipper: SilderClipper(),
                                    child: Container(
                                      height: 15,
                                      color: AppColors.lightGrayLittleColor,
                                      width: 15,
                                    ),
                                  ),
                                ),
                                Stack(
                                  children: [
                                    CircleIcon(
                                      icon: StoreangelIcons.location_pin_full,
                                      iconColor: AppColors.whiteColor,
                                      backgroundColor: AppColors.primaryColor,
                                    ),
                                    Positioned.fill(
                                        child: Align(
                                          alignment: Alignment.topRight,
                                          child: SizedBox(
                                              height: SizeConfig.smallerImageheight * .3,
                                              child: SvgPicture.asset(AssetsPath.green_border_selected)),
                                        ))
                                  ],
                                ),
                                Container(
                                  height: 5,
                                  width: SizeConfig.screenWidth * .13,
                                  color: AppColors.lightGrayLittleColor,
                                ),
                                Flexible(
                                  child: ClipPath(
                                    clipper: SilderClipper(),
                                    child: Container(
                                      height: 15,
                                      color: AppColors.lightGrayLittleColor,
                                      width: 15,
                                    ),
                                  ),
                                ),
                                CircleIcon(
                                  icon: StoreangelIcons.calculator_icon,
                                  backgroundColor: AppColors.lightGrayLittleColor,
                                  iconColor: AppColors.black,
                                ),
                              ],
                            ),
                          ),
                          Spacer(flex: 4,)
                        ],
                      ),
                    ),
                  ),
                ),
                expandedHeight:
                SizeConfig.expandedHeight,
              ),
              SliverList(
                delegate: SliverChildListDelegate([
                  SizeConfig.CVerticalSpaceMedium(),
                  Padding(
                    padding: SizeConfig.sidepadding,
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            AppStrings.YOUR_DELIVERY_LOCATION.tr() + ':',
                            textAlign: TextAlign.left,
                            style: AppStyles.BlackStyleWithBold800Font_20(context),
                          ),
                        ),
                        InkWell(
                          child: AppConstants.addIcon,
                          onTap: () {
                            TextEditingController controller = TextEditingController();
                            TextEditingController addressController = TextEditingController();
                            BottomSheetViewForSearch().onImageClick(
                                context,
                                controller,
                                true,
                                false,
                                0.0,
                                0.0,
                                addressController, (Place val) {
                              deliveryLocationViewModel.addAddress(AddressModel(
                                name: val.name,
                              ));
                            });
                          },
                        )
                      ],
                    ),
                  ),
                  SizeConfig.verticalSpace(4),
                  Padding(
                    padding: SizeConfig.sidepadding,
                    child: ListView.builder(
                        itemCount: deliveryLocationViewModel.addresses.length,
                        physics: NeverScrollableScrollPhysics(),
                        padding: EdgeInsets.all(0),
                        shrinkWrap: true,
                        itemBuilder: (context, int index) {
                          bool isSlected = deliveryLocationViewModel.selectedAddress ==
                              deliveryLocationViewModel.addresses[index];
                          return Padding(
                            padding: SizeConfig.smallerVerticalPadding3,
                            child: InkWell(
                              child: Container(
                                child: Padding(
                                  padding: SizeConfig.padding,
                                  child: Row(
                                    children: [
                                      DeliveryLocationCheckBoxWidget(value: isSlected),
                                      SizeConfig.horizontalSpaceSmall(),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              deliveryLocationViewModel.addresses[index].name,
                                              style: isSlected
                                                  ? AppStyles.WhiteStyleWithBold800_Font16
                                                  : AppStyles.BlackStyleWithBold800Font_16(context),
                                            ),
                                            SizeConfig.CVerticalSpaceVarySmall(),
                                            Text(
                                              deliveryLocationViewModel.addresses[index].address,
                                              style: isSlected
                                                  ? AppStyles.WhiteStyle_Font16
                                                  : AppStyles.BlackStyleFont_16(context),
                                            )
                                          ],
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                                decoration: BoxDecoration(
                                    color:
                                    isSlected ? Theme
                                        .of(context)
                                        .primaryColor : Theme
                                        .of(context)
                                        .backgroundColor,
                                    borderRadius: BorderRadius.circular(SizeConfig.radiusSmall)),
                              ),
                              onTap: () {
                                deliveryLocationViewModel
                                    .onSelectAddress(deliveryLocationViewModel.addresses[index]);
                              },
                            ),
                          );
                        }),
                  ),
                  SizeConfig.CVerticalSpacevMedium(),
                  Padding(
                    padding: SizeConfig.sidepadding,
                    child: Text(
                      AppStrings.DELIVERY_TYPE.tr() + ':',
                      textAlign: TextAlign.left,
                      style: AppStyles.BlackStyleWithBold800Font_20(context),
                    ),
                  ),
                  SizeConfig.CVerticalSpaceSmallMediumC11(),
                  Padding(
                    padding: SizeConfig.sidepadding,
                    child: SingleLineSelectableOption(
                      title: AppStrings.LEAVE_AT_DESTINATION.tr(),
                      value: deliveryLocationViewModel.leaveAtDestination,
                      onTap: () {
                        deliveryLocationViewModel.updateDestinationType();
                      },
                    ),
                  ),
                  SizeConfig.CVerticalSpacevMedium(),
                  Padding(
                    padding: SizeConfig.sidepadding,
                    child: Text(
                      AppStrings.ORDER_PAYMENT.tr() + ':',
                      textAlign: TextAlign.left,
                      style: AppStyles.BlackStyleWithBold800Font_20(context),
                    ),
                  ),
                  SizeConfig.CVerticalSpaceSmallMediumC11(),
                  Padding(
                    padding: SizeConfig.sidepadding,
                    child: ListView.builder(
                        itemCount: deliveryLocationViewModel.paymentOptions.length,
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        padding: EdgeInsets.all(0),
                        itemBuilder: (context, int index) {
                          return Padding(
                            padding: SizeConfig.smallerVerticalPadding3,
                            child: SingleLineSelectableOption(
                              title: deliveryLocationViewModel.paymentOptions[index].title,
                              value: deliveryLocationViewModel.selectedOption.paymentOptionEnum ==
                                  deliveryLocationViewModel.paymentOptions[index].paymentOptionEnum,
                              onTap: () {
                                deliveryLocationViewModel
                                    .onSelectPayOption(deliveryLocationViewModel.paymentOptions[index]);
                              },
                              child:
                                  deliveryLocationViewModel.paymentOptions[index].paymentOptionEnum ==
                                      PaymentOptionEnum.payment_on_delivery
                                  ? Padding(
                                padding: EdgeInsets.only(top: 8),
                                child:GestureDetector(
                                  onTap: (){
                                    if(deliveryLocationViewModel.selectedOption.paymentOptionEnum ==
                                        PaymentOptionEnum.payment_on_delivery){
                                      deliveryLocationViewModel.changePaymentRestriction();
                                    }

                                  },
                                  child: Padding(
                                    padding: SizeConfig.innerMediumPadding.copyWith(left: 0),
                                    child: Row(
                                      children: [
                                        DeliveryLocationCheckBoxWidget(
                                          value: deliveryLocationViewModel.purchaseDetails.paymentOption.paymentRestriction==PaymentRestriction.yes?true:false,
                                        ),
                                        SizeConfig.horizontalSpaceSmall(),
                                        Expanded(
                                          child: Text(
                                            AppStrings.WITH_BUDGET_RESTRICTION.tr(),
                                            style:AppStyles.WhiteStyleWithBold800_Font16,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              )
                                  : Container(),
                            ),
                          );
                        }),
                  ),
                  SizeConfig.CVerticalSpacevMedium(),
                  Padding(
                    padding: SizeConfig.sidepadding,
                    child: Text(
                      AppStrings.DELIVERY_DATE.tr() + ':',
                      textAlign: TextAlign.left,
                      style: AppStyles.BlackStyleWithBold800Font_20(context),
                    ),
                  ),
                  SizeConfig.CVerticalSpaceSmallMediumC11(),
                  Padding(
                    padding: SizeConfig.sidepadding,
                    child: SingleLineSelectableOption(
                      title: AppStrings.AS_SOON_AS_POSSIBLE.tr(),
                      value: deliveryLocationViewModel.deliveryTimeSelectValue == 1,
                      onTap: () {
                        deliveryLocationViewModel.onSelectDeliveryTimeOption(1);
                      },
                    ),
                  ),
                  SizeConfig.verticalSpaceSmall(),
                  Padding(
                    padding: SizeConfig.sidepadding,
                    child: SingleLineSelectableOption(
                      title: AppStrings.TOMORROW_DELIVERY.tr(),
                      value: deliveryLocationViewModel.deliveryTimeSelectValue == 2,
                      onTap: () {
                        deliveryLocationViewModel.onSelectDeliveryTimeOption(2);
                      },
                    ),
                  ),
                  SizeConfig.verticalSpaceSmall(),
                  Padding(
                    padding: SizeConfig.sidepadding,
                    child: SingleLineSelectableOption(
                      title: deliveryLocationViewModel.selectDateAndTime != null
                          ? deliveryLocationViewModel.selectDateAndTime
                          : AppStrings.SELECT_DELIVERY_DATE.tr(),
                      value: deliveryLocationViewModel.deliveryTimeSelectValue == 3,
                      onTap: () => onTapSelectDate(deliveryLocationViewModel, context),
                    ),
                  ),
                  SizeConfig.CVerticalSpacevMedium(),
                  Padding(
                    padding: SizeConfig.sidepadding,
                    child: Text(
                      AppStrings.COMMENT.tr() + ':',
                      textAlign: TextAlign.left,
                      style: AppStyles.BlackStyleWithBold800Font_20(context),
                    ),
                  ),
                  Padding(
                    padding: SizeConfig.padding,
                    child: Container(
                      decoration: BoxDecoration(
                          color: Theme
                              .of(context)
                              .cardColor,
                          borderRadius: BorderRadius.circular(AppConstants.button_Radius)),
                      child: Padding(
                        padding: SizeConfig.padding,
                        child: TextField(
                          focusNode: _commentNode,
                          minLines: 4,
                          maxLines: 4,
                          textInputAction: TextInputAction.done,
                          style: AppStyles.BlackStyleFont_20(context),
                          onTap: () {
                            Future.delayed(Duration(milliseconds: 300),
                                    () => StatusBarService.changeStatusBarColor(StatusBarType.Light, context));
                          },
                          onSubmitted: (txt) {
                            Future.delayed(Duration(milliseconds: 500),
                                    () => StatusBarService.changeStatusBarColor(StatusBarType.Light, context));
                          },
                          decoration: InputDecoration.collapsed(
                              hintText: '', hintStyle: AppStyles.GrayStyle_Font16(context)),
                        ),
                      ),
                    ),
                  ),
                  SizeConfig.CVerticalSpacevMedium(),
                  Padding(
                    padding: EdgeInsets.only(
                        left: SizeConfig.padding.left,
                        right: SizeConfig.padding.right,
                        bottom: SizeConfig.screenHeight * .04),
                    child: ButtonWidget(
                        radius: AppConstants.button_Radius,
                        fontSize: AppConstants.fontSizeSmall,
                        buttonColor: Theme
                            .of(context)
                            .primaryColor,
                        buttonText: AppStrings.NEXT.tr(),
                        onPressed: () {
                          deliveryLocationViewModel.onPublishOrder(_scaffoldKey);
                        }),
                  )
                ]),
              ),
            ],
          ),
        );
      },
    );
  }

  void onTapSelectDate(DeliveryLocationViewModel deliveryLocationViewModel, BuildContext context) {
    ShowBottomSheet.showLarge(
        child: CustomDatePickerWidget(
          minuteInterval:1,
          initialDatetime: deliveryLocationViewModel.intialatedateTime,
          bottomText: AppStrings.NEXT_SELECT_END_TIME.tr(),
          onSelect: (dateTime) {
            deliveryLocationViewModel.onSelectStartDate(dateTime);
            if (dateTime != null) {
              Navigator.pop(context);
              ShowBottomSheet.showLarge(
                  child: CustomDatePickerWidget(
                    minuteInterval: 1,
                    initialDatetime: deliveryLocationViewModel.startDate.add(Duration(hours: 2)),
                    bottomText: AppStrings.DELIVERY_UNTIL.tr(),
                    minimumDate:deliveryLocationViewModel.startDate.add(Duration(hours: 2)),
                    onSelect: (dateTime) {
                      if (dateTime != null) {
                        deliveryLocationViewModel.onSelectEndDate(dateTime);
                        deliveryLocationViewModel.onSelectDeliveryTimeOption(3);
                        deliveryLocationViewModel.navigatorPop();
                      } else {
                        deliveryLocationViewModel.navigatorPop();
                      }
                    },
                  ),
                  context: context,
                  heightFactor: .4);
            }
          },
        ),
        context: context,
        heightFactor: .4);
  }
}
