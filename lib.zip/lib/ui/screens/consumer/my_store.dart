import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:storeangelApp/core/consts/appConstants.dart';
import 'package:storeangelApp/core/consts/appString.dart';
import 'package:storeangelApp/core/consts/sizeConfig.dart';
import 'package:storeangelApp/core/consts/text_styles.dart';
import 'package:storeangelApp/core/enums/mobileSize.dart';
import 'package:storeangelApp/core/viewmodel/viewmodel_mystore.dart';
import 'package:storeangelApp/ui/screens/consumer/pick_Store_Screen.dart';
import 'package:storeangelApp/ui/screens/premiumScreen.dart';
import 'package:storeangelApp/ui/shared/app_header.dart';
import 'package:storeangelApp/ui/shared/base_model.dart';
import 'package:storeangelApp/ui/shared/base_view.dart';
import 'package:storeangelApp/ui/shared/customScaffold.dart';
import 'package:storeangelApp/ui/shared/premium_card.dart';
import 'package:storeangelApp/ui/shared/view_store.dart';

class MyStoreScreen extends StatefulWidget {
  @override
  _MyStoreScreenState createState() => _MyStoreScreenState();
}

class _MyStoreScreenState extends State<MyStoreScreen> {
  ScrollController _scrollController = ScrollController();

  @override
  void dispose() {
    super.dispose();
    _scrollController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BaseView<MyStoreViewModel>(
      onModelReady: (myStoreViewModel) => myStoreViewModel.initialize(_scrollController),
      builder: (context, myStoreViewModel, child) {
        return CustomScaffold(
          body: Column(
            children: [
              Expanded(
                child: myStoreViewModel.state == ViewState.Busy
                    ? AppConstants.circulerProgressIndicator()
                    : Padding(
                        padding: SizeConfig.sidepadding,
                        child: ListView.builder(
                            padding: SizeConfig.topAppbarPadding,
                            controller: _scrollController,
                            itemCount: myStoreViewModel.stores.length+1,
                            shrinkWrap: true,

                            itemBuilder: (context, int index) {
                              if(index==0){
                                return   AppHeader(
                                  title:AppStrings.YOUR_STORES.tr() ,
                                  subtitle:AppStrings.HERE_YOU_CAN_ALSO_FIND_THE_RESPECTIVE_TOPLISTS.tr() ,
                                  secondChild: InkWell(
                                    child: AppConstants.addIcon,
                                    onTap: () {
                                      if (myStoreViewModel.stores.length >= 3) {
                                        myStoreViewModel.navigateToScreen(PremiumScreen.routeName);
                                      } else {
                                        myStoreViewModel.navigateToScreen(PickStoreScreen.routeName,
                                            arguments: PickStoreScreenArguments(isMyStoreScreen: true));
                                      }
                                    },
                                  ),
                                );
                              }
                              return Padding(
                                padding: EdgeInsets.only(bottom: SizeConfig.bottomPadding.bottom),
                                child: ViewStore(
                                  store: myStoreViewModel.stores[index-1],
                                  onDelete: () {
                                    myStoreViewModel.onDeleteStore(myStoreViewModel.stores[index-1]);
                                  },
                                ),
                              );
                            }),
                      ),
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Padding(
                    padding: EdgeInsets.only(top: SizeConfig.screenHeight * .01),
                    child: SizedBox(
                      width: SizeConfig.screenWidth * .85,
                      child: Text(
                        AppStrings.STORE_ALERT_MESSAGE.tr(),
                        style: SizeConfig.mobileSize == MobileSize.small
                            ? AppStyles.BlackStyleFont_20(context).copyWith(
                          height: 1
                        )
                            : AppStyles.BlackStyleFontWeightSmall_17(context).copyWith(
                            height:1
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                  SizeConfig.verticalSpaceSmall(),
                  Padding(
                      padding: SizeConfig.padding,
                      child: PremiumCard(
                        title: AppStrings.GET_PREMIUM_NOW.tr(),
                        subtitle: AppStrings.PREMIUM_SUBTITLE_STORES.tr(),
                      )),
                ],
              ),
              SizeConfig.CVerticalSpaceSmallMedium()
            ],
          ),
        );
      },
    );
  }
}
