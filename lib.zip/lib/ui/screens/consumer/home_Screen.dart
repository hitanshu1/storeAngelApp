import 'package:flutter/material.dart';
import 'package:storeangelApp/core/consts/sizeConfig.dart';
import 'package:storeangelApp/core/services/statusbar_service.dart';
import 'package:storeangelApp/core/viewmodel/home_viewmodel.dart';
import 'package:storeangelApp/ui/shared/base_view.dart';
import 'package:storeangelApp/ui/shared/customScaffold.dart';
import 'package:storeangelApp/ui/widgets/home/home_header.dart';
import 'package:storeangelApp/ui/widgets/home/home_purchases_tiles.dart';
import 'package:storeangelApp/ui/widgets/home/notificationTile.dart';

class HomeScreen extends StatelessWidget {

  EdgeInsets get sidePadding => SizeConfig.sidepadding;

  final smallLeftPadding = EdgeInsets.only(left: SizeConfig.screenWidth * 0.03);

  @override
  Widget build(BuildContext context) {
    StatusBarService.changeStatusBarColor(StatusBarType.Gray,context);
    return BaseView<HomeViewModel>(
      onModelReady: (homeViewModel) => homeViewModel.initialize(),
      builder: (context, homeViewModel, child) => CustomScaffold(
        resizeToAvoidBottomInset: false,
        body: Padding(
          padding: SizeConfig.topAppbarPadding,
          child: CustomScrollView(
              slivers: <Widget>[
                HomeHeader(sidePadding: sidePadding),
                NotificationTiles(sidePadding: sidePadding,),
                HomePurchasesTiles(sidePadding: sidePadding,),

              ],
            ),
          ),
        ),
    );
  }
}
