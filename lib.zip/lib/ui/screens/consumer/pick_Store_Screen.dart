import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';
import 'package:storeangelApp/core/consts/appConstants.dart';
import 'package:storeangelApp/core/consts/appString.dart';
import 'package:storeangelApp/core/consts/sizeConfig.dart';
import 'package:storeangelApp/core/consts/text_styles.dart';
import 'package:storeangelApp/core/models/firebase_storedata_model.dart';
import 'package:storeangelApp/core/viewmodel/pickStore_viewmodel.dart';
import 'package:storeangelApp/ui/shared/base_model.dart';
import 'package:storeangelApp/ui/shared/base_view.dart';
import 'package:storeangelApp/ui/shared/bottomsheet_search_view.dart';
import 'package:storeangelApp/ui/shared/button_widget.dart';
import 'package:storeangelApp/ui/shared/customScaffold.dart';
import 'package:storeangelApp/ui/shared/search_appbar_widget.dart';
import 'package:storeangelApp/ui/widgets/pick_store/nearby_listitem_widget.dart';
import 'package:storeangelApp/ui/widgets/pick_store/pickStoreTextField.dart';

import '../../../getIt.dart';

class PickStoreScreen extends StatefulWidget {
  static const String routeName = 'pickStore';
  final PickStoreScreenArguments arguments;

  PickStoreScreen({this.arguments});

  @override
  _PickStoreScreenState createState() => _PickStoreScreenState();
}

class _PickStoreScreenState extends State<PickStoreScreen> {
  List<StoreDataModel> selectedStoreList = <StoreDataModel>[];

  final _locationSearchController = TextEditingController();
  final _searchAddressTopController = TextEditingController(text: AppStrings.NUMBRECH_12.tr());
  final _searchNearbyStoreController = TextEditingController();
  final _searchController = TextEditingController();

  final FocusNode _searchNearbyStoreFocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    if (widget.arguments?.address != null) {
      _searchAddressTopController.text = widget.arguments.address;
    }
  }

  @override
  void dispose() {
    _locationSearchController.dispose();
    _searchAddressTopController.dispose();
    _searchNearbyStoreController.dispose();
    _searchController.dispose();
    _searchNearbyStoreFocusNode.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    SizeConfig.sizeConfigInit(context);
    return MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: getIt<PickStoreViewModel>()),
      ],
      child: BaseView<PickStoreViewModel>(
        onModelReady: (model) {
          model.getStoreData();
          model.textFieldNode = _searchNearbyStoreFocusNode;
          },
        builder: (context, pickStoreModel, child) => CustomScaffold(
          resizeToAvoidBottomInset: false,
//          appBar: SearchAppBar(
//            extraPadding: true,
//            title: _searchAddressTopController.text,
//            onpressed: () {
//              BottomSheetViewForSearch().onImageClick(context, _searchAddressTopController, true, false);
//            },
//          ),
          body: Stack(
            children: <Widget>[
              Container(
                height: SizeConfig.screenHeight,
                width: SizeConfig.screenWidth,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(AppConstants.RadiusMedium),
                        bottomRight: Radius.circular(AppConstants.RadiusMedium))),
                child: Container(
                  margin: EdgeInsets.fromLTRB(SizeConfig.screenWidth * 0.06, 10, SizeConfig.screenWidth * 0.06, 0),
                  child: CustomScrollView(
                    slivers: <Widget>[
                      SliverToBoxAdapter(
                        child: SizedBox(
                          height: SizeConfig.screenHeight * .02,
                        ),
                      ),
                      SliverToBoxAdapter(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            widget.arguments?.isMyStoreScreen??false?Text(
                              AppStrings.PICK_YOUR_STORE_NEARBY.tr(),
                              style: AppStyles.BlackStyleWithBold_FontC20(context),
                              textAlign: TextAlign.center,
                              maxLines: 2,
                            ):Text(
                              AppStrings.PICK_NEARBY_STORE_3.tr(),
                              style: AppStyles.BlackStyleWithBold_FontC20(context),
                              textAlign: TextAlign.center,
                              maxLines: 2,
                            ),SizedBox(
                              height: SizeConfig.screenHeight * .02,
                            ),
                            Text(
                              pickStoreModel.pickedStoreCount.toString() + AppStrings.PICKED.tr(),
                              style: AppStyles.GrayStyle_FontMedium(context),
                              textAlign: TextAlign.center,
                            ),
                            SizeConfig.CVerticalSpaceBig(),
                            PickStoreTextField(
                              model: pickStoreModel,
                              searchNearbyStoreController: _searchNearbyStoreController,
                              searchNearbyStoreFocusNode: _searchNearbyStoreFocusNode,
                            ),
                            SizeConfig.verticalSpace(SizeConfig.bottomPadding.bottom),
                          ],
                        ),
                      ),
                      pickStoreModel.state == ViewState.Busy
                          ? SliverToBoxAdapter(child: Center(child: CircularProgressIndicator()))
                          : pickStoreModel.searchList != null && pickStoreModel.searchList.length != 0
                              ? SliverList(
                                  delegate: SliverChildBuilderDelegate(
                                    (context, index) {
                                      if (pickStoreModel.searchList.length == index)
                                        return SizedBox(
                                          height: SizeConfig.screenHeight * .15,
                                        );
                                      return NearbyListItem(
                                        searchStoreList: pickStoreModel.storeDetailList,
                                        model: pickStoreModel,
                                        index: index,
                                      );
                                    },
                                    childCount: pickStoreModel.searchList.length + 1,
                                  ),
                                )
                              : SliverToBoxAdapter(
                                  child: Center(
                                    child: Text(AppStrings.NO_DATA_FOUND.tr()),
                                  ),
                                ),
                    ],
                  ),
                ),
              ),
              Positioned(
                bottom: SizeConfig.screenHeight * 0.06,
                child: Container(
                  padding: EdgeInsets.only(left: SizeConfig.screenWidth * 0.06, right: SizeConfig.screenWidth * 0.06),
                  width: SizeConfig.screenWidth,
                  child: Visibility(
                    visible: pickStoreModel.selectedStoreList.length > 0,
                    child: ButtonWidget(
                      buttonText: AppStrings.DONE.tr(),
                      buttonColor: Theme.of(context).primaryColor,
                      fontSize: SizeConfig.fontSizeMedium,
                      radius: SizeConfig.borderRadius,
                      textColor: Colors.white,
                      onPressed: () {
                        pickStoreModel.updateList();
                        if (widget.arguments?.isMyStoreScreen ?? false) {
                          pickStoreModel.popToScreen();
                        } else {
                          pickStoreModel.navigateToScreen();
                        }
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class PickStoreScreenArguments {
  String address;
  bool isMyStoreScreen;

  PickStoreScreenArguments({this.address: "", this.isMyStoreScreen: false});
}
