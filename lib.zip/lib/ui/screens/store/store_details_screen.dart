import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:storeangelApp/core/consts/appColors.dart';
import 'package:storeangelApp/core/consts/appConstants.dart';
import 'package:storeangelApp/core/consts/appString.dart';
import 'package:storeangelApp/core/consts/sizeConfig.dart';
import 'package:storeangelApp/core/consts/storeangel_icons_icons.dart';
import 'package:storeangelApp/core/consts/text_styles.dart';
import 'package:storeangelApp/core/models/firebase_storedata_model.dart';
import 'package:storeangelApp/core/viewmodel/viewmodel_store_details.dart';
import 'package:storeangelApp/ui/shared/rating_widget.dart';
import 'package:storeangelApp/ui/screens/order/store_catalogue_screen.dart';
import 'package:storeangelApp/ui/shared/base_model.dart';
import 'package:storeangelApp/ui/shared/base_view.dart';
import 'package:storeangelApp/ui/shared/buttonWithIcon.dart';
import 'package:storeangelApp/ui/shared/circleIcon.dart';
import 'package:storeangelApp/ui/shared/customAppBar.dart';
import 'package:storeangelApp/ui/shared/view_app_Image.dart';

class StoreDetailsScreen extends StatefulWidget {
  static const String routeName = 'storeDetailsScreen';

  final StoreDataModel store;

  StoreDetailsScreen({this.store});

  @override
  _StoreDetailsScreenState createState() => _StoreDetailsScreenState();
}

class _StoreDetailsScreenState extends State<StoreDetailsScreen> {
  ScrollController _scrollController = ScrollController();

  @override
  void dispose() {
    super.dispose();
    _scrollController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BaseView<StoreDetailsViewModel>(
      onModelReady: (storeDetailsViewModel) => storeDetailsViewModel.initialize(_scrollController),
      builder: (context, storeDetailsViewModel, child) {
        if (storeDetailsViewModel.state == ViewState.Busy) {
          return Scaffold(
              backgroundColor: Theme.of(context).backgroundColor,
              body: AppConstants.circulerProgressIndicator());
        }
        return Scaffold(
          appBar: CustomAppBar(
            title: Text(
              widget.store.name,
              style: AppStyles.BlackStyleWithBold800Font_24(context),
              textAlign: TextAlign.center,
            ),
            elevation: storeDetailsViewModel.hasShadow?4:0,
            leading: BackButton(
              color: Theme.of(context).iconTheme.color,
              onPressed: () {
                storeDetailsViewModel.navigatorPop();
              },
            ),
            backgroundColor: Theme.of(context).backgroundColor,
            actions: [
              IconButton(icon: Icon(StoreangelIcons.delete_icon, color: Theme.of(context).focusColor, size: SizeConfig.iconSize,),
                  onPressed: (){

                  })
            ],
          ),
          body: SingleChildScrollView(
            controller: _scrollController,
            physics: AlwaysScrollableScrollPhysics(),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: SizeConfig.sidepadding.copyWith(top: SizeConfig.verticalMediumPadding.top),
                  child: Stack(
                    children: [
                      ViewAppImage(
                        height: SizeConfig.adaptiveHeight(SizeConfig.appBarHeight * 2.2),
                        width: SizeConfig.screenWidth,
                        imageUrl: widget.store.image,
                        radius: SizeConfig.borderRadius,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(SizeConfig.borderRadius),
                          topRight: Radius.circular(SizeConfig.borderRadius)
                        ),
                      ),
                      Positioned.fill(
                          child: Align(
                        alignment: Alignment.bottomRight,
                        child: Padding(
                          padding: SizeConfig.paddingWihLittleHeight,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              CircleIcon(
                                icon: Icons.favorite,
                                iconColor: AppColors.primaryColor,
                                backgroundColor: Theme.of(context).cardColor,
                                size: Size(
                                    SizeConfig.paddingWihLittleHeight.top * 2 +
                                        AppStyles.BlackStyleFont_16(context).fontSize +
                                        4,
                                    SizeConfig.paddingWihLittleHeight.top * 2 +
                                        AppStyles.BlackStyleFont_16(context).fontSize +
                                        4),
                              ),
                              SizeConfig.horizontalSpaceSmall(),
                              Container(
                                child: Padding(
                                  padding: SizeConfig.paddingWihLittleHeight,
                                  child: Row(
                                    children: [
                                      Icon(
                                        Icons.people_alt_outlined,
                                        color: Theme.of(context).focusColor,
                                        size: AppStyles.BlackStyleFont_16(context).fontSize + 4,
                                      ),
                                      SizedBox(
                                        width: 4,
                                      ),
                                      Text(
                                        '1230',
                                        style: AppStyles.BlackStyleFont_16(context),
                                      )
                                    ],
                                  ),
                                ),
                                decoration: BoxDecoration(
                                    color: Theme.of(context).cardColor, borderRadius: BorderRadius.circular(20)),
                              ),
                            ],
                          ),
                        ),
                      )),
                    ],
                  ),
                ),
                SizeConfig.CVerticalSpacevEMedium(),
                Padding(
                  padding: SizeConfig.sidepadding,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                          child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            widget.store.street,
                            style: AppStyles.GrayStyle_FontMedium(context),
                          ),
                          Text(
                            widget.store.zipCity,
                            style: AppStyles.GrayStyle_FontMedium(context),
                          ),
                        ],
                      )),
                      SizedBox(
                        width: 16,
                      ),
                      Text(
                        '300 m',
                        style: AppStyles.GreenStyleWithBoldFont_24(context),
                      )
                    ],
                  ),
                ),
                SizeConfig.CVerticalSpaceMedium(),
                Padding(
                  padding: SizeConfig.sidepadding,
                  child: RatingWidget(
                    objectHeader: AppStrings.STORE_RATING.tr(),
                    onRatingUpdate: (val) {},
                    objectName: widget.store.name,
                    headerStyle: AppStyles.BlackStyleWithBold800Font_20(context),
                  ),
                ),
                SizeConfig.verticalSpaceSmall(),
                Padding(
                  padding: SizeConfig.sidepadding,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        AppStrings.OPENING_HOUR.tr()+':',
                        style: AppStyles.BlackStyleWithBold800Font_20(context),
                      ),
                      Padding(
                          padding: EdgeInsets.only(top: 12),
                          child: Text('08:00 - 22:00', style: AppStyles.BlackStyleFont_20(context),))
                    ],
                  ),
                ),
                SizeConfig.CVerticalSpaceMedium25(),
                Padding(
                  padding: SizeConfig.sidepadding,
                  child: Container(
                    decoration:
                        BoxDecoration(color: Theme.of(context).cardColor, borderRadius: BorderRadius.circular(AppConstants.ContainerRoundCorner_Radius)),
                    padding: SizeConfig.sidepadding,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizeConfig.CVerticalSpaceMedium(),
                        Text(
                          AppStrings.CONTACT.tr(),
                          style: AppStyles.GreenStyleWithBold800_Font20(context),
                        ),
                        SizeConfig.CVerticalSpaceSmallMedium(),
                        Text(
                          'rewe.de',
                          style: AppStyles.BlackStyleFont_20(context).copyWith(fontWeight: FontWeight.w500),
                        ),
                        SizeConfig.verticalSpace(7),
                        Text(
                          'info@rewe.de',
                          style: AppStyles.BlackStyleFont_20(context).copyWith(fontWeight: FontWeight.w500),
                        ),
                        SizeConfig.verticalSpace(7),
                        Text(
                          '+49 3085743549',
                          style: AppStyles.BlackStyleFont_20(context).copyWith(fontWeight: FontWeight.w500),
                        ),
                        SizeConfig.CVerticalSpaceMedium(),
                      ],
                    ),
                  ),
                ),
                SizeConfig.CVerticalSpacevEMedium(),
                Padding(
                  padding: SizeConfig.sidepadding,
                  child: ButtonWithIcon(
                    buttonText: '${AppStrings.CREATE_A_LIST_FROM.tr()}',
                    onPressed: () {
                      storeDetailsViewModel.navigatorPop();
                      storeDetailsViewModel.navigateToScreen(StoreCatalogueScreen.routeName, arguments: widget.store);
                    },
                    space: true,
                    icon: Icons.add_circle,
                    iconColor: AppColors.whiteColor,
                    buttonColor: Theme.of(context).primaryColor,
                    radius: AppConstants.button_Radius,
                    fontSize: SizeConfig.fontSizeMedium,
                  ),
                ),
                SizeConfig.verticalSpaceMedium(),
              ],
            ),
          ),
        );
      },
    );
  }
}
