import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/provider.dart';
import 'package:storeangelApp/core/consts/appColors.dart';
import 'package:storeangelApp/core/consts/appConstants.dart';
import 'package:storeangelApp/core/consts/apptheme.dart';
import 'package:storeangelApp/core/consts/assetsPath.dart';
import 'package:storeangelApp/core/consts/sizeConfig.dart';
import 'package:storeangelApp/core/consts/text_styles.dart';
import 'package:storeangelApp/core/viewmodel/apptheme_viewmodel.dart';
import 'package:storeangelApp/ui/screens/premiumScreen.dart';

class PremiumCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final EdgeInsets padding;
  final TextStyle titleStyle, subtitleStyle;
  final double imageHeight;

  PremiumCard({this.title, this.subtitle, this.padding, this.subtitleStyle, this.titleStyle, this.imageHeight});

  @override
  Widget build(BuildContext context) {
    bool imageHeightIsNotNull = imageHeight != null;
    return InkWell(
      onTap: () {
        Navigator.pushNamed(context, PremiumScreen.routeName);
      },
      child: Container(
        decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            border: Border.all(color: AppColors.green),
            borderRadius: BorderRadius.circular(AppConstants.ContainerRoundCorner_Radius)),
        child: Padding(
          padding: padding != null
              ? padding
              : EdgeInsets.only(
                  bottom: 5,
                  left: 10,
                  right: 10,
                  top: 5,
                ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    AutoSizeText(
                      title,
                      maxLines: 2,
                      minFontSize: 10,
                      maxFontSize: SizeConfig.fontSizeLarge,
                      style: titleStyle != null ? titleStyle : AppStyles.GreenStyleWithBoldFont_C20(context),
                    ),
                    SizeConfig.CVerticalSpaceVarySmall(),
                    Text(
                      subtitle + '!',
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                      style: subtitleStyle != null ? subtitleStyle : AppStyles.BlackStyleWithBold500Font_14(context),
                    ),
                  ],
                ),
              ),
              SizeConfig.horizontalSpaceSmall(),
              Material(
                color: Provider.of<AppThemeViewModel>(context).themeData == AppTheme.dark
                    ? AppColors.secondDarkCardColor
                    : AppColors.whiteColor,
                elevation: 4,
                shape: CircleBorder(),
                child: SizedBox(
                  height: imageHeight ?? SizeConfig.mediumImageheight,
                  child: Padding(
                    padding: EdgeInsets.all(imageHeightIsNotNull
                        ? imageHeight * .2 + SizeConfig.mediumImageheight * .025
                        : SizeConfig.mediumImageheight * .2 + SizeConfig.mediumImageheight * .025),
                    child: SvgPicture.asset(
                      AssetsPath.trophy,
                      height: imageHeightIsNotNull ? imageHeight / 2.5 : SizeConfig.mediumImageheight * .3,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
