import 'package:flutter/material.dart';
import 'package:storeangelApp/core/consts/appColors.dart';
import 'package:storeangelApp/core/consts/appConstants.dart';
import 'package:storeangelApp/core/consts/sizeConfig.dart';

class ButtonWithIcon extends StatelessWidget {
  final String buttonText;
  final Color buttonColor;
  final double radius;
  final Color textColor;
  final double fontSize;
  final GestureTapCallback onPressed;
  final double height;
  final Color iconColor;
  final bool space;
  final double weight;
  final IconData icon;
  final double iconSize;

  ButtonWithIcon(
      {Key key,
        @required this.buttonText,
        @required this.onPressed,
        this.buttonColor,
        this.weight,
        this.radius,
        this.textColor,
        this.fontSize,
        this.icon,
        this.iconSize,
        this.iconColor,
        this.space:false,
        this.height})
      : assert(buttonText != null, 'You need to include the buttonText for this button'),
        assert(onPressed != null, 'Without an onPressed this button does make not a lot of sense. Please include!'),
        super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onPressed,
      child: Container(
        decoration: BoxDecoration(
          color: buttonColor ?? Colors.black,
          borderRadius: BorderRadius.circular(AppConstants.button_Radius),
        ),
        height: SizeConfig.buttonHeight,
        width: weight??SizeConfig.screenWidth,
        child: Padding(
          padding: SizeConfig.sidepadding,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                buttonText,
                style: TextStyle(color: textColor ?? AppColors.whiteColor, fontSize: fontSize ?? SizeConfig.fontSizeSmall),
              ),
             space?Spacer():SizeConfig.horizontalSpaceSmall(),
              Icon(icon,size: iconSize??SizeConfig.iconSize,color: iconColor!=null?iconColor:AppColors.whiteColor,)
            ],
          ),
        ),
      ),
    );
  }
}
