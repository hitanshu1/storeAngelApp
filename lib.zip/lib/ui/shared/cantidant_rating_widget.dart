import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:storeangelApp/core/consts/appColors.dart';
import 'package:storeangelApp/core/consts/appConstants.dart';
import 'package:storeangelApp/core/consts/sizeConfig.dart';
import 'package:storeangelApp/core/consts/storeangel_icons_icons.dart';
import 'package:storeangelApp/core/consts/text_styles.dart';

class CustomRatingWidget extends StatelessWidget {
  final int reviewCount;
  final double initialRating;
  final double stars;

  CustomRatingWidget({@required this.reviewCount,@required  this.initialRating,@required  this.stars});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(StoreangelIcons.profile_consumer_tab,size: SizeConfig.smallIconSize,),
        SizeConfig.horizontalSpace(SizeConfig.screenWidth*.01),
        Text(
          '$reviewCount ',
          style: AppStyles.BlackStyleFont300_16(context),
        ),
        SizeConfig.horizontalSpace(SizeConfig.screenWidth*.01),
        IgnorePointer(
          ignoring: true,
          child: FlutterRatingBar(
            initialRating: initialRating,
            itemCount: AppConstants.Ratingbar_item_count,
            itemSize: AppConstants.Ratingbar_itemSize,
            fillColor: AppColors.primaryColor,
            borderColor: Theme
                .of(context)
                .textTheme
                .headline4
                .color,
            allowHalfRating: true,
            onRatingUpdate: (rating) {
              print(rating);
            },
          ),
        ),
        SizeConfig.horizontalSpace(SizeConfig.screenWidth*.02),
        Text(
          '(${AppConstants.ratingAfterConvert(stars)})',
          style: AppStyles.BlackStyleFont300_16(context),
        )
      ],
    );
  }
}
