import 'package:flutter/material.dart';
import 'package:storeangelApp/core/consts/sizeConfig.dart';
import 'package:storeangelApp/core/consts/text_styles.dart';

class AppHeader extends StatelessWidget {
  final Widget secondChild;
  final String title;
  final String subtitle;

  const AppHeader({Key key,this.secondChild,this.title,this.subtitle}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: SizeConfig.smalltopPadding.copyWith(
        left: 0,right: 0
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizeConfig.CVerticalSpace60(),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                SizedBox(
                  child: Text(
                    title,
                    style: AppStyles.GreenStyleWithBoldFont_24(context),
                    textAlign: TextAlign.start,
                  ),
                ),
                SizedBox(
                  height: 4,
                ),
                Text(
                  subtitle,
                  style: AppStyles.BlackStyleFontw300_20(context),
                  textAlign: TextAlign.start,
                ),
                SizedBox(
                  height: 6,
                ),

              ],
            ),
          ),
          secondChild!=null?secondChild:Container()
        ],
      ),
    );
  }
}
